export AWS_PROFILE=533267175550_EasyJet-App-PowerUser

terraform apply \
    -var-file "./input-vars/common.tfvars" \
    -var-file "./input-vars/eresconnect-prod.tfvars" \
    -var env_type=PROD \
    -var tag_git_source=https://github.com/easyjet-dev/eres-connect-ejplus/ \
    -var tag_git_sha=14e3f7ea9b29424e65b8cb224251eeb781568972 \
    -var tag_git_branch=main \
    -var provider_iam_role=arn:aws:iam::533267175550:role/AWSReservedSSO_EasyJet-App-PowerUser_5fe16f5287034900


    # -var aws_account_id=533267175550 \
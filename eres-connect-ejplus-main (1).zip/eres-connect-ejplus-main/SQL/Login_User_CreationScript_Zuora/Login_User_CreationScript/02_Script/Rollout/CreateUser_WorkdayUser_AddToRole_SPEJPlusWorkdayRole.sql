USE [ejReservation]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (
		SELECT 1
		FROM [sys].[database_principals]
		WHERE [name] = N'DCP.ERESC.ejPlusWorkday.NONPROD'
		)
BEGIN
	IF EXISTS (
			SELECT 1
			FROM sys.server_principals
			WHERE NAME = N'DCP.ERESC.ejPlusWorkday.NONPROD'
			)
	BEGIN
		CREATE USER [DCP.ERESC.ejPlusWorkday.NONPROD]
		FOR LOGIN [DCP.ERESC.ejPlusWorkday.NONPROD]

		PRINT 'SUCCESS : User mapped to ejReservation database for account DCP.ERESC.ejPlusWorkday.NONPROD.'
	END
	ELSE
	BEGIN
		PRINT 'FAIL : DCP.ERESC.ejPlusWorkday.NONPROD account does not exist on Server.'
	END
END
ELSE
BEGIN
	PRINT 'Fail: DCP.ERESC.ejPlusWorkday.NONPROD user already exists in ejReservation.'
END
GO

-----------------------End USER-------------------------------
---------------------ADD user to role---------------------------
IF EXISTS (
		SELECT 1
		FROM [sys].[database_principals]
		WHERE [name] = N'ancillaryplusCard.Lambda'
		)
BEGIN
	IF EXISTS (
			SELECT 1
			FROM sys.database_principals
			WHERE NAME = N'DCP.ERESC.ejPlusWorkday.NONPROD'
			)
	BEGIN
		IF NOT EXISTS (
				SELECT 1
				FROM sys.database_role_members
				WHERE role_principal_id = DATABASE_PRINCIPAL_ID('ancillaryplusCard.Lambda')
					AND member_principal_id = DATABASE_PRINCIPAL_ID('DCP.ERESC.ejPlusWorkday.NONPROD')
				)
		BEGIN
			ALTER ROLE [ancillaryplusCard.Lambda] ADD MEMBER [DCP.ERESC.ejPlusWorkday.NONPROD]

			PRINT 'SUCCESS: DCP.ERESC.ejPlusWorkday.NONPROD user added to ancillaryplusCard.Lambda role in ejReservation'
		END
		ELSE
			PRINT 'FAIL: User DCP.ERESC.ejPlusWorkday.NONPROD already mapped to ancillaryplusCard.Lambda role in ejReservation'
	END
	ELSE
		PRINT 'FAIL: User DCP.ERESC.ejPlusWorkday.NONPROD does not exist in ejReservation'
END
ELSE
	PRINT 'FAIL: ancillaryplusCard.Lambda role not exist in ejReservation'
GO



USE [ejReservation]
GO 

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (
		SELECT 1
		FROM [sys].[database_principals]
		WHERE [name] = N'ancillaryplusCard.Lambda'
		)
BEGIN
	IF EXISTS (
			SELECT 1
			FROM sys.database_principals
			WHERE NAME = N'DCP.ERESC.ejPlusZuora.NONPROD'
			)
	BEGIN
		ALTER ROLE [ancillaryplusCard.Lambda]
		DROP MEMBER [DCP.ERESC.ejPlusZuora.NONPROD]

		PRINT 'ROLLBACK SUCCESS: DCP.ERESC.ejPlusZuora.NONPROD user dropped from ancillaryplusCard.Lambda role in ejReservation'
	END
	ELSE
		PRINT 'ROLLBACK FAIL: User DCP.ERESC.ejPlusZuora.NONPROD does not exist in ejReservation'
END
ELSE
	PRINT 'ROLLBACK FAIL: ancillaryplusCard.Lambda role not exist in ejReservation'
GO

------------------remove user------------------
-------------------------rollback user-------------------------------------
IF EXISTS (
		SELECT 1
		FROM [sys].[database_principals]
		WHERE [name] = N'DCP.ERESC.ejPlusZuora.NONPROD'
		)
BEGIN
	DROP USER [DCP.ERESC.ejPlusZuora.NONPROD]

	PRINT 'ROLLBACK SUCCESS: Successfully dropped User DCP.ERESC.ejPlusZuora.NONPROD from ejReservation'
END
ELSE
BEGIN
	PRINT 'ROLLBACK FAIL:  User DCP.ERESC.ejPlusZuora.NONPROD does not exist in ejReservation'
END
GO



USE [master]
GO 

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (
		SELECT 1
		FROM sys.server_principals
		WHERE NAME = N'DCP.ERESC.ejPlusWorkday.NONPROD'
		)
BEGIN
	CREATE LOGIN [DCP.ERESC.ejPlusWorkday.NONPROD]
		WITH PASSWORD = '' 
			,DEFAULT_DATABASE = [master]
			,CHECK_EXPIRATION = OFF
			,CHECK_POLICY = OFF

	PRINT 'Success: Account DCP.ERESC.ejPlusWorkday.NONPROD created on Master.'
END
ELSE
BEGIN
	PRINT 'Fail: Account DCP.ERESC.ejPlusWorkday.NONPROD already exists on Master.'
END
GO



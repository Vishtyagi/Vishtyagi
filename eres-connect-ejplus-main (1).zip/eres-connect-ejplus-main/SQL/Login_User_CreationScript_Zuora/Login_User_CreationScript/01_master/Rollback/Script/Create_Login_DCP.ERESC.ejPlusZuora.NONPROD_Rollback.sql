USE [master]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (
		SELECT 1
		FROM sys.server_principals
		WHERE NAME = N'DCP.ERESC.ejPlusZuora.NONPROD'
		)
BEGIN
	DROP LOGIN [DCP.ERESC.ejPlusZuora.NONPROD]

	PRINT 'ROLLBACK SUCCESS: Account DCP.ERESC.ejPlusZuora.NONPROD dropped successfully from Master'
END
ELSE
BEGIN
	PRINT 'ROLLBACK FAIL:  Account DCP.ERESC.ejPlusZuora.NONPROD does not exist on Master'
END
GO



USE [master]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (
		SELECT 1
		FROM sys.server_principals
		WHERE NAME = N'DCP.ERESC.ejPlusWorkday.NONPROD'
		)
BEGIN
	DROP LOGIN [DCP.ERESC.ejPlusWorkday.NONPROD]

	PRINT 'ROLLBACK SUCCESS: Account DCP.ERESC.ejPlusWorkday.NONPROD dropped successfully from Master'
END
ELSE
BEGIN
	PRINT 'ROLLBACK FAIL:  Account DCP.ERESC.ejPlusWorkday.NONPROD does not exist on Master'
END
GO



#!/bin/sh

awslocal s3api put-object \
  --bucket "ej-dcp-lambda-artefacts" \
  --key dcp-ancillary-pricing-set-price/index.zip \
  --body ../dist/ancillary-pricing-set-price/index.zip \
  --metadata "Tag=local"
  
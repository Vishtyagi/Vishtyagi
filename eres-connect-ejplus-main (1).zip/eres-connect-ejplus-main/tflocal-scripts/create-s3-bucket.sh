#!/bin/sh

awslocal s3api create-bucket --bucket "ej-dcp-lambda-artefacts" --region us-east-1
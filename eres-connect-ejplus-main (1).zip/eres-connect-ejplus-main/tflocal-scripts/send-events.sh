#!/bin/sh

awslocal events put-events --entries file://events.json
  
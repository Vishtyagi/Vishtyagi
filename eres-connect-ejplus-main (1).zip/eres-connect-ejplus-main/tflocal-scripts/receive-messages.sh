#!/bin/sh

while true; do
  awslocal sqs receive-message --queue-url http://localhost:4566/000000000000/AncillaryPriceChangev2 --attribute-names All --message-attribute-names All --max-number-of-messages 10
done

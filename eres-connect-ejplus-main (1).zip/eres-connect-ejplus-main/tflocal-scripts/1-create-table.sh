#!/bin/sh

awslocal dynamodb create-table --region eu-west-1 --cli-input-json file://../localstack-scripts/AncillaryPricing_TableSchema.json 
 
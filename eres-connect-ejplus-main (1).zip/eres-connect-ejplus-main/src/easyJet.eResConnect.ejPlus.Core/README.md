﻿This project is for the Split Booking logic.  Appropriate abstractions should be created here which can be invoked from the Lambda project (driven port) and implemented in TextReader B2BClient project (driving port).

This project must not reference other projects.
    
This project is expected to contain:
- async interface for B2B port
- manifest file object model
- async manifest file parsing
- validation logic and error handling
- orchestration of B2B calls via interface abstraction
- handling of B2B results indicating success and/or failures
- writing results back to manifest file
- appropriate logging


using System.Text.Json.Serialization;

namespace easyJet.eResConnect.ejPlus.Core.PayLoad
{
    public class SQSMessageDetail
    {
        [JsonPropertyName("data")]
        public SQSMessageKey Data { get; set; }

        [JsonPropertyName("metadata")]
        public SQSMessageMetadata Metadata { get; set; }
    }
}

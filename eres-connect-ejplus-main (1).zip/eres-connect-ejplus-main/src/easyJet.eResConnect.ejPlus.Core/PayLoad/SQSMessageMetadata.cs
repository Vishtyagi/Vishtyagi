using System.Text.Json.Serialization;

namespace easyJet.eResConnect.ejPlus.Core.PayLoad
{
    public class SQSMessageMetadata
    {
        [JsonPropertyName("correlation_id")]
        public string CorrelationId { get; set; }

        [JsonPropertyName("zuora_track_id")]
        public string ZuoraTrackId { get; set; }
    }
}

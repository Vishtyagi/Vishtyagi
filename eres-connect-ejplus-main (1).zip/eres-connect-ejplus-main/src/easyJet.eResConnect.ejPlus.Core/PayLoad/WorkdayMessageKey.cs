﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace easyJet.eResConnect.ejPlus.Core.PayLoad
{
    public class WorkdayMessageKey
    {
        [JsonPropertyName("CardNumber")]
        public string CardNumber { get; set; }

        [JsonPropertyName("FirstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("LastName")]
        public string LastName { get; set; }

        [JsonPropertyName("EmailAddress")]
        public string EmailAddress { get; set; }

        [JsonPropertyName("WorkerDateEnd")]
        public string WorkerDateEnd { get; set; }

        [JsonPropertyName("LastUpdated")]
        public string LastUpdated { get; set; }

    }
}

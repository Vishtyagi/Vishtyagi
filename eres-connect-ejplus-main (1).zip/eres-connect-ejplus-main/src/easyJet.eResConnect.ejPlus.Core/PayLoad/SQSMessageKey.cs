﻿using System.Text.Json.Serialization;

namespace easyJet.eResConnect.ejPlus.Core.PayLoad
{
    public class SQSMessageKey
    {
        [JsonPropertyName("membership_id")]
        public string MembershipId { get; set; }

        [JsonPropertyName("first_name")]
        public string FirstName { get; set; }

        [JsonPropertyName("last_name")]
        public string LastName { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }

        [JsonPropertyName("app_status")]
        public string AppStatus { get; set; }

        [JsonPropertyName("expiry_date")]
        public string ExpiryDate { get; set; }

        [JsonPropertyName("timedate")]
        public string Timedate { get; set; }

        [JsonPropertyName("event_type")]
        public string EventType { get; set; }
        public string SQSMessageID { get; set; } 
    }
}

﻿using easyJet.eResConnect.ejPlus.Core.PayLoad;
using System.Data;

namespace easyJet.eResConnect.ejPlus.Core.Repository
{
    public interface IPlusCardZuoraRepository
    {
        string ConnectionString { get; set; }
        DataTable ConvertToDataTable(List<SQSMessageKey> sqsMessageKey);
        DataTable ExecuteStoredProcedureWithDataTable(DataTable dataTable);
        DataSet ExecuteDataSetFromSp(string storedProcedureName, DataTable dataTable);
    }
}

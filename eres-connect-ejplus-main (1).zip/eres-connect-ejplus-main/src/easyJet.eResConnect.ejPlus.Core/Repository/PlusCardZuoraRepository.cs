﻿using System.Data;
using Microsoft.Data.SqlClient;
using easyJet.eResConnect.ejPlus.Core.PayLoad;
using Microsoft.Extensions.Logging;

namespace easyJet.eResConnect.ejPlus.Core.Repository
{
    public class PlusCardZuoraRepository : IPlusCardZuoraRepository
    {
        private readonly ILogger<PlusCardZuoraRepository> _logger;
        private string _connectionString;
        public string ConnectionString
        {
            get
            {
                return _connectionString;
            }
            set
            {
                _connectionString = value;
            }
        }
        public PlusCardZuoraRepository(ILogger<PlusCardZuoraRepository> logger)
        {
            _logger = logger;
        }
        public DataTable ConvertToDataTable(List<SQSMessageKey> sqsMessageKey)
        {

            DataTable dataTable = new DataTable();
            try
            {
                // Define columns
                dataTable.Columns.Add("CardNumber", typeof(string));
                dataTable.Columns.Add("FirstName", typeof(string));
                dataTable.Columns.Add("LastName", typeof(string));
                dataTable.Columns.Add("EmailAddress", typeof(string));
                dataTable.Columns.Add("ExpiryDate", typeof(DateTime));
                dataTable.Columns.Add("Status", typeof(string));
                dataTable.Columns.Add("SourceLastUpdatedDtTm", typeof(DateTime));
                dataTable.Columns.Add("EventType", typeof(char));
                dataTable.Columns.Add("SQSMessageID", typeof(Guid));

                foreach (var sqsMessage in sqsMessageKey)
                {
                    dataTable.Rows.Add(
                        sqsMessage.MembershipId,
                        sqsMessage.FirstName,
                        sqsMessage.LastName,
                        sqsMessage.Email,
                        DateTime.Parse(sqsMessage.ExpiryDate),
                        sqsMessage.AppStatus,
                        sqsMessage.Timedate,
                        sqsMessage.EventType.Equals("new", StringComparison.OrdinalIgnoreCase) ? 'N' : 'U',
                        sqsMessage.SQSMessageID
                    );
                }
            }
            catch (Exception dataTableException)
            {
                _logger.LogError(dataTableException, "Error converting SQSMessageKey json body to datatable.");
            }
            return dataTable;
        }
        public DataTable ExecuteStoredProcedureWithDataTable(DataTable dataTable)
        {
            DataTable resultTable = new DataTable();
            const string storedProcedureName = "ejReservation.ancillary.PlusCardZuora_upd";

            try
            {
                DataSet dataset = ExecuteDataSetFromSp(storedProcedureName, dataTable);

                if (dataset != null && dataset.Tables.Count > 0)
                {
                    resultTable = dataset.Tables[0];
                }
            }
            catch (Exception dbConnectionException)
            {
                _logger.LogError(dbConnectionException, "Error while executing stored procedure");
            }

            return resultTable;
        }

        public DataSet ExecuteDataSetFromSp(string storedProcedureName, DataTable dataTable)
        {
            DataSet dataSet = new DataSet();
            DataSet failureDataSet = new DataSet();
            failureDataSet.Tables.Add(dataTable);
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(storedProcedureName, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        SqlParameter tableParameter = command.Parameters.AddWithValue("PlusCardZuoraList", dataTable);
                        tableParameter.SqlDbType = SqlDbType.Structured;

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(dataSet);
                            _logger.LogInformation(storedProcedureName + " Stored procedure successfully executed.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    var messageIDList = new List<string>();
                    foreach (DataRow row in failureDataSet.Tables[0].Rows)
                    {
                        messageIDList.Add(row[8].ToString());
                    }
                    string logEntry = string.Join(", ", messageIDList);
                    _logger.LogError(ex, "Error while executing stored procedure " + storedProcedureName + "." + " For the MessageIDs: " + logEntry);
                    return failureDataSet;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                        connection.Dispose();
                    }
                }
            }
            return dataSet;
        }

    }
}

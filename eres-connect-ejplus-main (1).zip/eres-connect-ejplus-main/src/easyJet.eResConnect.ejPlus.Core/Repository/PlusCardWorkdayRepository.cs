﻿using easyJet.eResConnect.ejPlus.Core.PayLoad;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using System.Data;

namespace easyJet.eResConnect.ejPlus.Core.Repository
{
    public class PlusCardWorkdayRepository : IPlusCardWorkdayRepository
    {
        private readonly ILogger<PlusCardWorkdayRepository> _logger;
        private string _connectionString;
        public string ConnectionString
        {
            get
            {
                return _connectionString;
            }
            set
            {
                _connectionString = value;
            }
        }
        public PlusCardWorkdayRepository(ILogger<PlusCardWorkdayRepository> logger)
        {
            _logger = logger;
        }
        public DataTable ConvertToDataTable(List<WorkdayMessageKey> workdayMessageKeys)
        {

            DataTable dataTable = new DataTable();
            try
            {
                // Define columns
                dataTable.Columns.Add("CardNumber", typeof(string));
                dataTable.Columns.Add("FirstName", typeof(string));
                dataTable.Columns.Add("LastName", typeof(string));
                dataTable.Columns.Add("EmailAddress", typeof(string));
                dataTable.Columns.Add("ExpiryDate", typeof(DateTime));
                dataTable.Columns.Add("Status", typeof(string));
                dataTable.Columns.Add("SourceLastUpdatedDtTm", typeof(DateTime));

                foreach (var workdayMessage in workdayMessageKeys)
                {
                    dataTable.Rows.Add(
                        workdayMessage.CardNumber,
                        workdayMessage.FirstName,
                        workdayMessage.LastName,
                        workdayMessage.EmailAddress,
                        DateTime.Parse(workdayMessage.WorkerDateEnd),
                        "Completed",
                        workdayMessage.LastUpdated
                    );
                }
            }
            catch (Exception dataTableException)
            {
                _logger.LogError(dataTableException, "Error converting workdayMessageKey json body to datatable.");
            }
            return dataTable;
        }
        public bool ExecuteStoredProcedureWithDataTable(DataTable dataTable)
        {
            const string storedProcedureName = "ejReservation.ancillary.PlusCardWorkday_upd";
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(storedProcedureName, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        SqlParameter tableParameter = command.Parameters.AddWithValue("PlusCardWorkdayList", dataTable);
                        tableParameter.SqlDbType = SqlDbType.Structured;
                        command.ExecuteNonQuery();

                        _logger.LogInformation(storedProcedureName + " Stored procedure successfully executed.");
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error while executing stored procedure " + storedProcedureName + ".");
                    return false;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                        connection.Dispose();
                    }
                }
            }
        }
    }
}

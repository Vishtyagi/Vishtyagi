﻿using easyJet.eResConnect.ejPlus.Core.PayLoad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace easyJet.eResConnect.ejPlus.Core.Repository
{
    public interface IPlusCardWorkdayRepository
    {
        string ConnectionString { get; set; }
        DataTable ConvertToDataTable(List<WorkdayMessageKey> workdayMessageKeys);
        bool ExecuteStoredProcedureWithDataTable(DataTable dataTable);
    }
}

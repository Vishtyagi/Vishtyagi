﻿using Amazon.Lambda.CloudWatchEvents;
using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using Amazon.SQS;
using easyJet.eResConnect.ejPlus.Core.PayLoad;
using easyJet.eResConnect.ejPlus.Core.Repository;
using easyJet.eResConnect.ejPlus.Zuora.Lambda;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System.Text.Json;

namespace easyJet.eResConnect.ejPlus.Zuora.LambdaTest
{
    public class LambdaHandlerTest
    {
        private readonly Mock<ILogger<LambdaHandler>> _mockLogger;
        private readonly Mock<IConfiguration> _mockConfiguration;
        private readonly Mock<IAmazonSQS> _mockSqsClient;
        private readonly Mock<IPlusCardZuoraSQSLambda> _mockPlusCardZuoraSQSLambda;
        private readonly Mock<IPlusCardZuoraRepository> _mockPlusCardZuoraRepository;
        private readonly LambdaHandler _lambdaHandler;
        private readonly Mock<ILambdaContext> _mockContext;

        private readonly Mock<IConfigurationSection> _mockConfigurationSection;


        public LambdaHandlerTest()
        {
            _mockLogger = new Mock<ILogger<LambdaHandler>>();
            _mockConfiguration = new Mock<IConfiguration>();
            _mockSqsClient = new Mock<IAmazonSQS>();
            _mockPlusCardZuoraSQSLambda = new Mock<IPlusCardZuoraSQSLambda>();
            _mockPlusCardZuoraRepository = new Mock<IPlusCardZuoraRepository>();
            _mockContext = new Mock<ILambdaContext>();
            _mockConfigurationSection = new Mock<IConfigurationSection>();
            _lambdaHandler = new LambdaHandler(
                _mockLogger.Object,
                _mockSqsClient.Object,
                _mockConfiguration.Object,
                _mockPlusCardZuoraSQSLambda.Object,
                _mockPlusCardZuoraRepository.Object
            );

            _mockContext.SetupGet(c => c.AwsRequestId).Returns("test-request-id");
            _mockConfigurationSection.SetupGet(m => m[It.Is<string>(s => s == "eResReservation")]).Returns("fake-connection-string");

            // Mock the IConfigurationSection for the connection string


        }

        [Fact]
        public async Task Handler_ValidMessages_NoErrors()
        {
            // Arrange
            var sqsMessageDetail = new SQSMessageDetail
            {
                Data = new SQSMessageKey
                {
                    MembershipId = "123",
                    FirstName = "John",
                    LastName = "Doe",
                    Email = "john.doe@example.com",
                    AppStatus = "Active",
                    ExpiryDate = "2070-01-01",
                    Timedate = "2020-01-01T12:00:00",
                    EventType = "New",
                    SQSMessageID = "1"
                }
            };
            var cloudWatchEvent1 = new CloudWatchEvent<SQSMessageDetail>
            {
                Detail = sqsMessageDetail
            };


            var sqsEvent = new SQSEvent
            {
                Records = new List<SQSEvent.SQSMessage>
                {
                    new SQSEvent.SQSMessage
                    {
                        Body = JsonSerializer.Serialize(cloudWatchEvent1),
                        MessageId = "msg1"
                    }
                }
            };

            _mockConfiguration.Setup(a => a.GetSection(It.Is<string>(s => s == "ConnectionStrings"))).Returns(_mockConfigurationSection.Object);
            _mockConfiguration.Setup(x => x["InvalidRecordBucket"]).Returns("test-bucket");
            _mockPlusCardZuoraSQSLambda.Setup(x => x.ProcessSQSMessages(It.IsAny<Dictionary<string, SQSMessageKey>>()))
       .ReturnsAsync(new SQSBatchResponse(new List<SQSBatchResponse.BatchItemFailure>()));


            // Act
            var response = await _lambdaHandler.Handler(sqsEvent, _mockContext.Object);

            // Assert
            Assert.NotNull(response);
            Assert.Empty(response.BatchItemFailures);
            
            _mockPlusCardZuoraSQSLambda.Verify(x => x.ProcessSQSMessages(It.IsAny<Dictionary<string, SQSMessageKey>>()), Times.Once);
        }

        [Fact]
        public async Task Handler_EmptyEvent_LogsInformation()
        {
            // Arrange
            var sqsEvent = new SQSEvent { Records = null };

            // Act
            var response = await _lambdaHandler.Handler(sqsEvent, _mockContext.Object);

            // Assert
            Assert.NotNull(response);
            Assert.Empty(response.BatchItemFailures);
            
        }
        [Fact]
        public async Task Handler_DeserializationError_LogsError()
        {
            // Arrange
            var sqsEvent = new SQSEvent
            {
                Records = new List<SQSEvent.SQSMessage>
                {
                    new SQSEvent.SQSMessage
                    {
                        Body = "Invalid JSON",
                        MessageId = "msg1"
                    }
                }
            };

            _mockConfiguration.Setup(x => x["InvalidRecordBucket"]).Returns("test-bucket");
            _mockConfiguration.Setup(a => a.GetSection(It.Is<string>(s => s == "ConnectionStrings"))).Returns(_mockConfigurationSection.Object);
            _mockPlusCardZuoraSQSLambda.Setup(x => x.ProcessSQSMessages(It.IsAny<Dictionary<string, SQSMessageKey>>()))
        .ReturnsAsync(new SQSBatchResponse(new List<SQSBatchResponse.BatchItemFailure>()));

            // Act
            var response = await _lambdaHandler.Handler(sqsEvent, _mockContext.Object);

            // Assert
            Assert.NotNull(response);
            Assert.Empty(response.BatchItemFailures);

            _mockPlusCardZuoraSQSLambda.Verify(x => x.ProcessSQSMessages(It.IsAny<Dictionary<string, SQSMessageKey>>()), Times.Once);

        }
        [Fact]
        public async Task Handler_DuplicateMembershipId_ProcessesLatestRecord()
        {
            // Arrange
            
            var sqsMessageDetail1 = new SQSMessageDetail
            {
                Data = new SQSMessageKey
                {
                    MembershipId = "123",
                    FirstName = "John",
                    LastName = "Doe",
                    Email = "john.doe@example.com",
                    AppStatus = "Active",
                    ExpiryDate = "2070-01-01",
                    Timedate = "2020-01-01T12:00:00",
                    EventType = "New",
                    SQSMessageID = "1"
                }
            };

            var sqsMessageDetail2 = new SQSMessageDetail
            {
                Data = new SQSMessageKey
                {
                    MembershipId = "123",
                    FirstName = "John",
                    LastName = "Doe",
                    Email = "john.doe@example.com",
                    AppStatus = "Active",
                    ExpiryDate = "2070-01-01",
                    Timedate = "2021-01-01T12:00:00",
                    EventType = "Update",
                    SQSMessageID = "2"
                }
            };

            var cloudWatchEvent1 = new CloudWatchEvent<SQSMessageDetail>
            {
                Detail = sqsMessageDetail1
            };

            var cloudWatchEvent2 = new CloudWatchEvent<SQSMessageDetail>
            {
                Detail = sqsMessageDetail2
            };

            var sqsEvent = new SQSEvent
            {
                Records = new List<SQSEvent.SQSMessage>
                {
                    new SQSEvent.SQSMessage
                    {
                        Body = JsonSerializer.Serialize(cloudWatchEvent1),
                        MessageId = "msg1"
                    },
                    new SQSEvent.SQSMessage
                    {
                        Body = JsonSerializer.Serialize(cloudWatchEvent2),
                        MessageId = "msg2"
                    }
                }
            };

            _mockConfiguration.Setup(x => x["InvalidRecordBucket"]).Returns("test-bucket");
            _mockConfiguration.Setup(a => a.GetSection(It.Is<string>(s => s == "ConnectionStrings"))).Returns(_mockConfigurationSection.Object);
            _mockPlusCardZuoraSQSLambda.Setup(x => x.ProcessSQSMessages(It.IsAny<Dictionary<string, SQSMessageKey>>()))
        .ReturnsAsync(new SQSBatchResponse(new List<SQSBatchResponse.BatchItemFailure>()));

            // Act
            var response = await _lambdaHandler.Handler(sqsEvent, _mockContext.Object);

            // Assert
            Assert.NotNull(response);
            Assert.Empty(response.BatchItemFailures);
            _mockPlusCardZuoraSQSLambda.Verify(x => x.ProcessSQSMessages(It.Is<Dictionary<string, SQSMessageKey>>(dict => dict["123"].EventType == "Update")), Times.Once);
        }
    }
    }

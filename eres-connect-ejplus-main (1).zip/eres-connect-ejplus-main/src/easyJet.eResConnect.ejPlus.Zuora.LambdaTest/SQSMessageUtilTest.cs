using easyJet.eResConnect.ejPlus.Core.PayLoad;
using easyJet.eResConnect.ejPlus.Zuora.Lambda;
using Microsoft.Extensions.Logging;
using Moq;

namespace easyJet.eResConnect.ejPlus.Zuora.LambdaTest
{
    public class SQSMessageUtilTest
    {
        private readonly Mock<ILogger<SQSMessageUtil>> _mockLogger;
        private readonly SQSMessageUtil _sqsMessageUtil;

        public SQSMessageUtilTest()
        {
            _mockLogger = new Mock<ILogger<SQSMessageUtil>>();
            _sqsMessageUtil = new SQSMessageUtil(_mockLogger.Object);
        }

        [Fact]
        public void SQSMessageValidation_ValidMessage_ReturnsEmptyList()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "2070-01-01",
                Timedate = "2020-01-01T12:00:00",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Empty(result);
        }
        [Fact]
        public void SQSMessageValidation_MissingMandatoryField_MembershipID_ReturnsValidationMessages()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "2070-01-01",
                Timedate = "2020-01-01T12:00:00",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("membership_id is a mandatory Field.", result);
            
        }
        [Fact]
        public void SQSMessageValidation_MissingMandatoryField_FirstName_ReturnsValidationMessages()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "2070-01-01",
                Timedate = "2020-01-01T12:00:00",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("first_name is a mandatory Field.", result);

        }
        [Fact]
        public void SQSMessageValidation_MissingMandatoryField_LastName_ReturnsValidationMessages()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "2070-01-01",
                Timedate = "2020-01-01T12:00:00",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("last_name is a mandatory Field.", result);

        }
        [Fact]
        public void SQSMessageValidation_MissingMandatoryField_Appstatus_ReturnsValidationMessages()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "",
                ExpiryDate = "2070-01-01",
                Timedate = "2020-01-01T12:00:00",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("app_status is a mandatory Field.", result);

        }
        [Fact]
        public void SQSMessageValidation_MissingMandatoryField_ExpiryDate_ReturnsValidationMessages()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "",
                Timedate = "2020-01-01T12:00:00",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("expiry_date is a mandatory Field.", result);

        }
        [Fact]
        public void SQSMessageValidation_MissingMandatoryField_Timedate_ReturnsValidationMessages()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "2070-01-01",
                Timedate = "",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("timedate is a mandatory Field", result);
        }
        [Fact]
        public void SQSMessageValidation_MissingMandatoryField_EventType_ReturnsValidationMessages()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "2070-01-01",
                Timedate = "2020-01-01T12:00:00",
                EventType = ""
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("event_type is a mandatory Field", result);

        }
        [Fact]
        public void SQSMessageValidation_Invalid_MmbershipID_ReturnsValidationMessage()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "ABCDEFGHIJ123456789010",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "2070-01-01",
                Timedate = "2020-01-01T12:00:00",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("membership_id cannot have more then 20 characters.", result);
        }
        [Fact]
        public void SQSMessageValidation_Invalid_AppStatus_ReturnsValidationMessage()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "ActiveCompletedInactiveTestTest",
                ExpiryDate = "2070-01-01",
                Timedate = "InvalidDateTime",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("app_status cannot have more than 20 characters.", result);
        }
        [Fact]
        public void SQSMessageValidation_Invalid_EventType_ReturnsValidationMessage()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "2070-01-01",
                Timedate = "2020-01-01T12:00:00",
                EventType = "InvalidType"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);
            
            // Assert
            Assert.Contains("event_type cannot have value other then 'New' or 'Update'.", result);
        }

        [Fact]
        public void SQSMessageValidation_Invalid_Timedate_ReturnsValidationMessage()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "1800-01-01",
                Timedate = "InvalidDateTime",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("timedate should be in a format which can be converted into DateTime.", result);
        }
        [Fact]
        public void SQSMessageValidation_Invalid_ExpiryDate_ReturnsValidationMessage()
        {
            // Arrange
            var message = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "1800-01-01",
                Timedate = "2020-01-01T12:00:00",
                EventType = "New"
            };

            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(message);

            // Assert
            Assert.Contains("expiry_date should be between minSmallDateTime and maxSmallDateTime.", result);
        }

        [Fact]
        public void SQSMessageValidatation_WhenSQSObjectIsNUll()
        {
            // Act
            var result = _sqsMessageUtil.SQSMessageValidatation(null);

            // Assert
            Assert.Empty(result);
        }
    }
}
﻿using Amazon.S3.Model;
using Amazon.S3;
using easyJet.eResConnect.ejPlus.Core.PayLoad;
using easyJet.eResConnect.ejPlus.Core.Repository;
using easyJet.eResConnect.ejPlus.Zuora.Lambda;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System.Data;
using Amazon.Lambda.SQSEvents;

namespace easyJet.eResConnect.ejPlus.Zuora.LambdaTest
{
    public class PlusCardZuoraSQSLambdaTest
    {
        private readonly Mock<ILogger<PlusCardZuoraSQSLambda>> _mockLogger;
        private readonly Mock<IPlusCardZuoraRepository> _mockPlusCardZuoraRepository;
        private readonly Mock<ISQSMessageUtil> _mockSQSMessageUtil;
        private readonly Mock<IPlusCardZuoraSQSLambda> _plusCardZuoraSQSLambdaInterface;
        private readonly Mock<IAmazonS3> _mockS3Client;
        private readonly PlusCardZuoraSQSLambda _plusCardZuoraSQSLambda;

        public PlusCardZuoraSQSLambdaTest()
        {
            _mockLogger = new Mock<ILogger<PlusCardZuoraSQSLambda>>();
            _mockPlusCardZuoraRepository = new Mock<IPlusCardZuoraRepository>();
            _mockSQSMessageUtil = new Mock<ISQSMessageUtil>();
            _mockS3Client = new Mock<IAmazonS3>();

            _plusCardZuoraSQSLambda = new PlusCardZuoraSQSLambda(_mockS3Client.Object, _mockLogger.Object, _mockPlusCardZuoraRepository.Object, _mockSQSMessageUtil.Object)
            {

                S3BucketName = "test-bucket",
            };

        }
        [Fact]
        public async Task ProcessSQSMessages_ValidMessages_NoErrors()
        {
            // Arrange
            var dict = new Dictionary<string, SQSMessageKey>
            {
                { "msg1", new SQSMessageKey { MembershipId = "123", FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", AppStatus = "Active", ExpiryDate = "2070-01-01", Timedate = "2020-01-01T12:00:00", EventType = "New", SQSMessageID = "1" } }
             };
            var mockDataTable = new DataTable();
            mockDataTable.Columns.Add("MembershipId");
            mockDataTable.Columns.Add("FirstName");
            mockDataTable.Columns.Add("LastName");
            mockDataTable.Columns.Add("Email");
            mockDataTable.Columns.Add("AppStatus");
            mockDataTable.Columns.Add("ExpiryDate");
            mockDataTable.Columns.Add("Timedate");
            mockDataTable.Columns.Add("EventType");
            mockDataTable.Columns.Add("SQSMessageID");

            var row = mockDataTable.NewRow();
            row["MembershipId"] = "123";
            row["FirstName"] = "John";
            row["LastName"] = "Doe";
            row["Email"] = "john.doe@example.com";
            row["AppStatus"] = "Active";
            row["ExpiryDate"] = "2070-01-01";
            row["Timedate"] = "2020-01-01T12:00:00";
            row["EventType"] = "New";
            row["SQSMessageID"] = "1";
            mockDataTable.Rows.Add(row);

            _mockSQSMessageUtil.Setup(x => x.SQSMessageValidatation(It.IsAny<SQSMessageKey>())).Returns(new List<string>());
            _mockPlusCardZuoraRepository.Setup(x => x.ConvertToDataTable(It.IsAny<List<SQSMessageKey>>())).Returns(mockDataTable);
            _mockPlusCardZuoraRepository.Setup(x => x.ExecuteStoredProcedureWithDataTable(It.IsAny<System.Data.DataTable>())).Returns(mockDataTable);
            _mockS3Client.Setup(x => x.PutObjectAsync(It.IsAny<PutObjectRequest>(), default)).ReturnsAsync(new PutObjectResponse());

            // Act
            var result = await _plusCardZuoraSQSLambda.ProcessSQSMessages(dict);

            // Assert
            //_mockSQSMessageUtil.Verify(util => util.SQSMessageValidatation(It.IsAny<SQSMessageKey>()), Times.Once);
            _mockPlusCardZuoraRepository.Verify(repo => repo.ConvertToDataTable(It.IsAny<List<SQSMessageKey>>()), Times.Once); 
            _mockPlusCardZuoraRepository.Verify(repo => repo.ExecuteStoredProcedureWithDataTable(It.IsAny<DataTable>()), Times.Once);
            //_mockS3Client.Verify(s => s.PutObjectAsync(It.IsAny<PutObjectRequest>(), default), Times.Once);
        }
        [Fact]
        public async Task ProcessSQSMessages_ValidMessages_ConvertToDataTable_ExceptionThown()
        {
            // Arrange
            var dict = new Dictionary<string, SQSMessageKey>
            {
                { "msg1", new SQSMessageKey { MembershipId = "123", FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", AppStatus = "Active", ExpiryDate = "2070-01-01", Timedate = "2020-01-01T12:00:00", EventType = "New", SQSMessageID = "1" } }
             };

            _mockSQSMessageUtil.Setup(x => x.SQSMessageValidatation(It.IsAny<SQSMessageKey>())).Returns(new List<string>());
            _mockPlusCardZuoraRepository.Setup(x => x.ConvertToDataTable(It.IsAny<List<SQSMessageKey>>())).Throws(new Exception("Test Exception"));

            // Act
            await _plusCardZuoraSQSLambda.ProcessSQSMessages(dict);

            // Assert
            _mockSQSMessageUtil.Verify(util => util.SQSMessageValidatation(It.IsAny<SQSMessageKey>()), Times.Once);
            _mockPlusCardZuoraRepository.Verify(repo => repo.ConvertToDataTable(It.IsAny<List<SQSMessageKey>>()), Times.Once);
        }
        [Fact]
        public async Task ProcessSQSMessages_ValidMessages_ExecuteStoredProcedureWithDataTable_ExceptionThown()
        {
            // Arrange
            var dict = new Dictionary<string, SQSMessageKey>
            {
                { "msg1", new SQSMessageKey { MembershipId = "123", FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", AppStatus = "Active", ExpiryDate = "2070-01-01", Timedate = "2020-01-01T12:00:00", EventType = "New", SQSMessageID = "1" } }
             };
            var mockDataTable = new DataTable();
            mockDataTable.Columns.Add("MembershipId");
            mockDataTable.Columns.Add("FirstName");
            mockDataTable.Columns.Add("LastName");
            mockDataTable.Columns.Add("Email");
            mockDataTable.Columns.Add("AppStatus");
            mockDataTable.Columns.Add("ExpiryDate");
            mockDataTable.Columns.Add("Timedate");
            mockDataTable.Columns.Add("EventType");
            mockDataTable.Columns.Add("SQSMessageID");

            var row = mockDataTable.NewRow();
            row["MembershipId"] = "123";
            row["FirstName"] = "John";
            row["LastName"] = "Doe";
            row["Email"] = "john.doe@example.com";
            row["AppStatus"] = "Active";
            row["ExpiryDate"] = "2070-01-01";
            row["Timedate"] = "2020-01-01T12:00:00";
            row["EventType"] = "New";
            row["SQSMessageID"] = "1";
            mockDataTable.Rows.Add(row);

            _mockSQSMessageUtil.Setup(x => x.SQSMessageValidatation(It.IsAny<SQSMessageKey>())).Returns(new List<string>());
            _mockPlusCardZuoraRepository.Setup(x => x.ConvertToDataTable(It.IsAny<List<SQSMessageKey>>())).Returns(mockDataTable);
             _mockPlusCardZuoraRepository.Setup(x => x.ExecuteStoredProcedureWithDataTable(It.IsAny<System.Data.DataTable>())).Throws(new Exception("Test exception"));
            // Act
            await _plusCardZuoraSQSLambda.ProcessSQSMessages(dict);

            // Assert
            _mockSQSMessageUtil.Verify(util => util.SQSMessageValidatation(It.IsAny<SQSMessageKey>()), Times.Once);
            _mockPlusCardZuoraRepository.Verify(repo => repo.ConvertToDataTable(It.IsAny<List<SQSMessageKey>>()), Times.Once);
            _mockPlusCardZuoraRepository.Verify(repo => repo.ExecuteStoredProcedureWithDataTable(It.IsAny<DataTable>()), Times.Once);
        }

        [Fact]
        public async Task ProcessSQSMessages_ValidationFailure_MessagePushedToS3()
        {
            // Arrange
            var dict = new Dictionary<string, SQSMessageKey>
            {
                { "msg1", new SQSMessageKey { MembershipId = "123", FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", AppStatus = "Active", ExpiryDate = "2070-01-01", Timedate = "2020-01-01T12:00:00", EventType = "New", SQSMessageID = "1" } }
            };
            _mockSQSMessageUtil.Setup(util => util.SQSMessageValidatation(It.IsAny<SQSMessageKey>())).Returns(new List<string> { "Error" });
            _mockS3Client.Setup(x => x.PutObjectAsync(It.IsAny<PutObjectRequest>(), default)).ReturnsAsync(new PutObjectResponse());
            
            // Act
            await _plusCardZuoraSQSLambda.ProcessSQSMessages(dict);

            // Assert
            _mockSQSMessageUtil.Verify(util => util.SQSMessageValidatation(It.IsAny<SQSMessageKey>()), Times.Once);
            _mockS3Client.Verify(s => s.PutObjectAsync(It.IsAny<PutObjectRequest>(), default), Times.Once);

        }
        [Fact]
        public async Task ProcessSQSMessages_ExceptionThrown_ErrorLogged()
        {
            // Arrange
            var validMessage = new SQSMessageKey
            {
                MembershipId = "123",
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@example.com",
                AppStatus = "Active",
                ExpiryDate = "2070-01-01",
                Timedate = "2020-01-01T12:00:00",
                EventType = "New",
                SQSMessageID = "2"
            };
            var messages = new Dictionary<string, SQSMessageKey>
            {
                { "message1", validMessage }
            };

            _mockSQSMessageUtil.Setup(util => util.SQSMessageValidatation(It.IsAny<SQSMessageKey>()))
            .Throws(new Exception("Test exception"));

            // Act
            await _plusCardZuoraSQSLambda.ProcessSQSMessages(messages);

            // Assert
            _mockSQSMessageUtil.Verify(util => util.SQSMessageValidatation(It.IsAny<SQSMessageKey>()), Times.Once);
        }
    
        [Fact]
        public void GenerateFailureJson_ValidInput_ReturnsCorrectJson()
        {
            // Arrange
            var sqsMessages = new List<SQSMessageKey>
            {
                new SQSMessageKey { MembershipId = "123", FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", AppStatus = "Active", ExpiryDate = "2070-01-01", Timedate = "2020-01-01T12:00:00", EventType = "New", SQSMessageID = "1" }
            };
            var failureReasons = new List<string> { "Error" };

            // Act
            var result = _plusCardZuoraSQSLambda.GenerateFailureJson(sqsMessages, failureReasons);

            // Assert
            Assert.NotNull(result);
            var deserializedResult = JsonConvert.DeserializeObject<dynamic>(result);
            Assert.Equal("123", (string)deserializedResult.original_message[0].membership_id);
        }

        [Fact]
        public void GenerateFailureJson_InvalidInput_ThrowsException()
        {
            // Arrange
            List<SQSMessageKey> sqsMessages = null; // Invalid input
            var failureReasons = new List<string> { "Error" };
            //Act
            var result = _plusCardZuoraSQSLambda.GenerateFailureJson(sqsMessages, failureReasons);

            //Assert 
            Assert.NotNull(result);
            
            var deserializedResult = JsonConvert.DeserializeObject<dynamic>(result);
            Assert.Equal(null, (string)deserializedResult.original_message);

        }
        
        [Fact]
        public async Task StoreFailureMessagesInS3_ValidJson_Success()
        {
            // Arrange
            var failureJson = "{}";
            _mockS3Client.Setup(x => x.PutObjectAsync(It.IsAny<PutObjectRequest>(), default)).ReturnsAsync(new PutObjectResponse());
            string sqsMessageID = "13456789jyv";
            // Act
             await _plusCardZuoraSQSLambda.StoreFailureMessagesInS3(failureJson, sqsMessageID);

            // Assert
            _mockS3Client.Verify(s => s.PutObjectAsync(It.Is<PutObjectRequest>(req =>
                req.BucketName == "test-bucket" &&
                req.ContentBody == failureJson &&
                req.ContentType == "application/json" &&
                req.Key.StartsWith("Zuora/failed-Zuora-")), default), Times.Once);
        }

        [Fact]
        public async Task StoreFailureMessagesInS3_InvalidJson_ThrowsException()
        {
            // Arrange
            var failureJson = "{ invalid json";
            _mockS3Client.Setup(x => x.PutObjectAsync(It.IsAny<PutObjectRequest>(), default)).ThrowsAsync(new AmazonS3Exception("Invalid JSON"));

            string sqsMessageID = "13456789jyv";
            // Act
            await _plusCardZuoraSQSLambda.StoreFailureMessagesInS3(failureJson, sqsMessageID);

            // Assert
            _mockS3Client.Verify(s => s.PutObjectAsync(It.Is<PutObjectRequest>(req =>
                req.BucketName == "test-bucket" &&
                req.ContentBody == failureJson &&
                req.ContentType == "application/json" &&
                req.Key.StartsWith("Zuora/failed-Zuora-")), default), Times.Once);

        }
    }
}

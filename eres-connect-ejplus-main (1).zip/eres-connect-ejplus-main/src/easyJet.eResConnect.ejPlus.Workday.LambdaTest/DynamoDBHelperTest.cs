﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using easyJet.eResConnect.ejPlus.Workday.Lambda;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace easyJet.eResConnect.ejPlus.Workday.LambdaTest
{
    public class DynamoDBHelperTest
    {
        private readonly Mock<IAmazonDynamoDB> _mockdynamoDb;
        private readonly Mock<ILogger<DynamoDBHelper>> _mocklogger;
        private readonly Mock<IDynamoDBHelper> _mockdynamoDBHelper;
        private readonly DynamoDBHelper _dynamoDbHelper;
        public string TableName { get; set; }
        public string KeyName { get; set; }
        public string KeyAttribute { get; set; }
        public DynamoDBHelperTest()
        {
            _mockdynamoDBHelper = new Mock<IDynamoDBHelper>();
            _mockdynamoDb = new Mock<IAmazonDynamoDB>();
            _mocklogger =   new Mock<ILogger<DynamoDBHelper>>();
            _dynamoDbHelper = new DynamoDBHelper(_mockdynamoDb.Object, _mocklogger.Object)
            {

            };
        }

        [Fact]
        public async Task IsTableEmptyAsync_TableIsEmpty_ReturnsAdjustedTimestamp()
        {
            // Arrange
            _mockdynamoDb.Setup(d => d.ScanAsync(It.IsAny<ScanRequest>(), default))
                .ReturnsAsync(new ScanResponse
                {
                    Items = new List<Dictionary<string, AttributeValue>>()
                });
            // Act
            var result = await _dynamoDbHelper.IsTableEmptyAsync(5);

            // Assert
            DateTime expectedDate = DateTime.UtcNow.AddDays(-5);
            string expectedTimestamp = expectedDate.ToString("yyyy-MM-ddTHH:mm:ssZ");
            Assert.StartsWith(expectedDate.ToString("yyyy-MM-dd"), result);
            
        }

        [Fact]
        public async Task IsTableEmptyAsync_TableIsNotEmpty_ReturnsTimestampFromTable()
        {
            // Arrange
            var dynamoDBTimestamp = DateTime.UtcNow;
            _mockdynamoDb.Setup(d => d.ScanAsync(It.IsAny<ScanRequest>(), default))
                .ReturnsAsync(new ScanResponse
                {
                    Items = new List<Dictionary<string, AttributeValue>>
                    {
                    new Dictionary<string, AttributeValue>
                    {
                        { "TimeStamp", new AttributeValue { S = dynamoDBTimestamp.ToString() } }
                    }
                    }
                });

            _dynamoDbHelper.KeyName = "TimeStampID";
            _dynamoDbHelper.KeyAttribute = "TimeStamp";
            //// Act
            var result = await _dynamoDbHelper.IsTableEmptyAsync(5);

            // Assert
            string expectedTimestamp = dynamoDBTimestamp.AddMinutes(-1).ToString("yyyy-MM-ddTHH:mm:ssZ");
            Assert.Equal(expectedTimestamp, result);
            
        }

        [Fact]
        public async Task IsTableEmptyAsync_ExceptionThrown_LogsErrorAndReturnsEmptyString()
        {
            // Arrange
            _mockdynamoDb.Setup(d => d.ScanAsync(It.IsAny<ScanRequest>(), default))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _dynamoDbHelper.IsTableEmptyAsync(5);

            // Assert
            Assert.Equal(string.Empty, result);
            
        }
        [Fact]
        public async Task UpdateTimestampInDynamoDB_UpdatesTimestampSuccessfully()
        {
            // Arrange
            _mockdynamoDb.Setup(d => d.PutItemAsync(It.IsAny<PutItemRequest>(), default))
                .ReturnsAsync(new PutItemResponse());

            PutItemRequest capturedRequest = null;
            _mockdynamoDb.Setup(d => d.PutItemAsync(It.IsAny<PutItemRequest>(), default))
                .Callback<PutItemRequest, System.Threading.CancellationToken>((req, token) => capturedRequest = req)
                .ReturnsAsync(new PutItemResponse());

            _dynamoDbHelper.TableName = "Workday";
            _dynamoDbHelper.KeyName = "TimeStampID";
            _dynamoDbHelper.KeyAttribute = "TimeStamp";
            // Act
            await _dynamoDbHelper.UpdateTimestampInDynamoDB();

            // AssertAssert.NotNull(capturedRequest);
            Assert.Equal("Workday", capturedRequest.TableName);
            Assert.True(capturedRequest.Item.ContainsKey("TimeStampID"));
            Assert.Equal("0", capturedRequest.Item["TimeStampID"].N);

            Assert.True(capturedRequest.Item.ContainsKey("TimeStamp"));
            Assert.NotNull(capturedRequest.Item["TimeStamp"].S);

            DateTime timestamp;
            bool isValidTimestamp = DateTime.TryParse(capturedRequest.Item["TimeStamp"].S, out timestamp);
            Assert.True(isValidTimestamp);

        }

        [Fact]
        public async Task UpdateTimestampInDynamoDB_LogsErrorOnException()
        {
            // Arrange
            var exception = new Exception("Test exception");
            _mockdynamoDb.Setup(d => d.PutItemAsync(It.IsAny<PutItemRequest>(), default))
                .ThrowsAsync(exception);

            _dynamoDbHelper.TableName = "Workday";
            _dynamoDbHelper.KeyName = "TimeStampID";
            _dynamoDbHelper.KeyAttribute = "TimeStamp";

            //Act
            var task = _dynamoDbHelper.UpdateTimestampInDynamoDB();

            // Assert
            await task;  // Verify that no exception is thrown to the caller
        }
    }
}

﻿using easyJet.eResConnect.ejPlus.Core.PayLoad;
using easyJet.eResConnect.ejPlus.Workday.Lambda;
using Microsoft.Extensions.Logging;
using Moq;

namespace easyJet.eResConnect.ejPlus.Workday.LambdaTest
{
    public class WorkdayMessagesUtilTest
    {

        private readonly Mock<ILogger<WorkdayMessagesUtil>> _mockLogger;
        private readonly WorkdayMessagesUtil _workdayMessagesUtil;

        public WorkdayMessagesUtilTest()
        {
            _mockLogger = new Mock<ILogger<WorkdayMessagesUtil>>();
            _workdayMessagesUtil = new WorkdayMessagesUtil(_mockLogger.Object);
        }

        [Fact]
        public void WorkdayMessageValidation_ValidMessage_ReturnsEmptyList()
        {
            // Arrange
            var message = new WorkdayMessageKey
            {
                CardNumber = "123",
                FirstName = "John",
                LastName = "Doe",
                EmailAddress = "john.doe@example.com",
                WorkerDateEnd = "2070-01-01",
                LastUpdated = "2020-01-01T12:00:00",
            };

            // Act
            var result = _workdayMessagesUtil.WorkdayMessagesValidation(message);

            // Assert
            Assert.Empty(result);
        }
        [Fact]
        public void WorkdayMessageValidation_MissingMandatoryField_CardNumber_ReturnsValidationMessages()
        {
            // Arrange
            var message = new WorkdayMessageKey
            {
                CardNumber = "",
                FirstName = "John",
                LastName = "Doe",
                EmailAddress = "john.doe@example.com",
                WorkerDateEnd = "2070-01-01",
                LastUpdated = "2020-01-01T12:00:00",
            };

            // Act
            var result = _workdayMessagesUtil.WorkdayMessagesValidation(message);

            // Assert
            Assert.Contains("CardNumber is a mandatory Field.", result);

        }
        [Fact]
        public void WorkdayMessageValidation_MissingMandatoryField_FirstName_ReturnsValidationMessages()
        {
            // Arrange
            var message = new WorkdayMessageKey
            {
                CardNumber = "123",
                FirstName = "",
                LastName = "Doe",
                EmailAddress = "john.doe@example.com",
                WorkerDateEnd = "2070-01-01",
                LastUpdated = "2020-01-01T12:00:00",
            };

            // Act
            var result = _workdayMessagesUtil.WorkdayMessagesValidation(message);

            // Assert
            Assert.Contains("first_name is a mandatory Field.", result);

        }
        [Fact]
        public void WorkdayMessageValidation_MissingMandatoryField_LastName_ReturnsValidationMessages()
        {
            // Arrange
            var message = new WorkdayMessageKey
            {
                CardNumber = "123",
                FirstName = "John",
                LastName = "",
                EmailAddress = "john.doe@example.com",
                WorkerDateEnd = "2070-01-01",
                LastUpdated = "2020-01-01T12:00:00",
            };

            // Act
            var result = _workdayMessagesUtil.WorkdayMessagesValidation(message);

            // Assert
            Assert.Contains("last_name is a mandatory Field.", result);

        }
        
        [Fact]
        public void WorkdayMessageValidation_MissingMandatoryField_LastUpdated_ReturnsValidationMessages()
        {
            // Arrange
            var message = new WorkdayMessageKey
            {
                CardNumber = "123",
                FirstName = "John",
                LastName = "Doe",
                EmailAddress = "john.doe@example.com",
                WorkerDateEnd = "2070-01-01",
                LastUpdated = "",
            };

            // Act
            var result = _workdayMessagesUtil.WorkdayMessagesValidation(message);

            // Assert
            Assert.Contains("LastUpdated is a mandatory Field.", result);
        }
        [Fact]
        public void WorkdayMessageValidation_MissingMandatoryField_EmailAddress_ReturnsValidationMessages()
        {
            // Arrange
            var message = new WorkdayMessageKey
            {
                CardNumber = "123",
                FirstName = "John",
                LastName = "Doe",
                EmailAddress = "",
                WorkerDateEnd = "2070-01-01",
                LastUpdated = "2020-01-01T12:00:00",
            };

            // Act
            var result = _workdayMessagesUtil.WorkdayMessagesValidation(message);

            // Assert
            Assert.Contains("email is a mandatory Field.", result);

        }
        [Fact]
        public void WorkdayMessageValidation_Invalid_Cardnumber_ReturnsValidationMessage()
        {
            // Arrange
            var message = new WorkdayMessageKey
            {
                CardNumber = "12319yfbnidxcvnmiyt345678io2",
                FirstName = "John",
                LastName = "Doe",
                EmailAddress = "john.doe@example.com",
                WorkerDateEnd = "2070-01-01",
                LastUpdated = "2020-01-01T12:00:00",
            };

            // Act
            var result = _workdayMessagesUtil.WorkdayMessagesValidation(message);

            // Assert
            Assert.Contains("CardNumber cannot have more then 20 characters.", result);
        }

        [Fact]
        public void WorkdayMessageValidation_Invalid_LastUpdated_ReturnsValidationMessage()
        {
            // Arrange
            var message = new WorkdayMessageKey
            {
                CardNumber = "123",
                FirstName = "John",
                LastName = "Doe",
                EmailAddress = "john.doe@example.com",
                WorkerDateEnd = "2070-01-01",
                LastUpdated = "test",
            };

            // Act
            var result = _workdayMessagesUtil.WorkdayMessagesValidation(message);

            // Assert
            Assert.Contains("LastUpdated should be in a format which can be converted into DateTime.", result);
        }
        [Fact]
        public void WorkdayMessageValidation_Invalid_WorkerDateEnd_ReturnsValidationMessage()
        {
            // Arrange
            var message = new WorkdayMessageKey
            {
                CardNumber = "123",
                FirstName = "John",
                LastName = "Doe",
                EmailAddress = "john.doe@example.com",
                WorkerDateEnd = "test",
                LastUpdated = "2020-01-01T12:00:00",
            };

            // Act
            var result = _workdayMessagesUtil.WorkdayMessagesValidation(message);

            // Assert
            Assert.Contains("WorkerDateEnd should be in a format which can be converted into SmallDateTime.", result);
        }

        [Fact]
        public void SQSMessageValidatation_WhenSQSObjectIsNUll()
        {
            // Act
            var result = _workdayMessagesUtil.WorkdayMessagesValidation(null);

            // Assert
            Assert.Empty(result);
        }
    }
}

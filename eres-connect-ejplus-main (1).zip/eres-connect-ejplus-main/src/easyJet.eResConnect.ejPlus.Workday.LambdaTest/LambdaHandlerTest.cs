﻿using Amazon.Lambda.Core;
using easyJet.eResConnect.ejPlus.Core.PayLoad;
using easyJet.eResConnect.ejPlus.Core.Repository;
using easyJet.eResConnect.ejPlus.Workday.Lambda;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;

namespace easyJet.eResConnect.ejPlus.Workday.LambdaTest
{
    public class LambdaHandlerTest
    {

        private readonly Mock<ILogger<LambdaHandler>> mockLogger = new();
        private readonly Mock<IConfiguration> mockConfiguration = new();
        private readonly Mock<IProcessWorkdayMessage> mockProcessWorkdayMessage = new();
        private readonly Mock<IPlusCardWorkdayRepository> mockPlusCardWorkdayRepository = new();
        private readonly Mock<ITokenRequestHandler> mockTokenRequestHandler = new();
        private readonly Mock<IDynamoDBHelper> mockDynamoDBHelper = new();

        private readonly Mock<ILambdaContext> mockContext = new();

        private readonly Mock<IConfigurationSection> mockConfigurationSection = new();
        private readonly LambdaHandler lambdaHandler;

        public LambdaHandlerTest()
        {
            lambdaHandler = new LambdaHandler(mockLogger.Object, mockConfiguration.Object, mockPlusCardWorkdayRepository.Object, mockProcessWorkdayMessage.Object, mockTokenRequestHandler.Object, mockDynamoDBHelper.Object);

            mockContext.SetupGet(c => c.AwsRequestId).Returns("test-request-id");
            mockConfigurationSection.SetupGet(m => m[It.Is<string>(s => s == "eResReservation")]).Returns("fake-connection-string");
            mockConfiguration.Setup(x => x["ClientSecret"]).Returns("test-client-secret");
            mockConfiguration.Setup(x => x["RefreshToken"]).Returns("test-refresh-token");
            mockConfiguration.Setup(x => x["TokenEndPoint"]).Returns("test-token-endpoint");
            mockConfiguration.Setup(x => x["DataEndPoint"]).Returns("test-data-endpoint");
            mockConfiguration.Setup(x => x["TimeOut"]).Returns("30");
            mockConfiguration.Setup(x => x["PreviousDays"]).Returns("7");
            mockConfiguration.Setup(x => x["InvalidRecordBucket"]).Returns("test-bucket");
            mockConfiguration.Setup(a => a.GetSection(It.Is<string>(s => s == "ConnectionStrings"))).Returns(mockConfigurationSection.Object);
            mockConfiguration.Setup(x => x["WorkdayTableKey:WorkdayTableName"]).Returns("test-table-name");
            mockConfiguration.Setup(x => x["WorkdayTableKey:WorkdayKeyName"]).Returns("test-key-name");
            mockConfiguration.Setup(x => x["WorkdayTableKey:WorkdayKeyAttribute"]).Returns("test-key-attribute");
        }
        [Fact]
        public async Task Handler_FetchesTokenAndProcessesDataSuccessfully()
        {
            // Arrange
            mockTokenRequestHandler.Setup(x => x.FetchTokenAsync()).ReturnsAsync("{\"access_token\": \"test-access-token\"}");
            mockDynamoDBHelper.Setup(x => x.IsTableEmptyAsync(It.IsAny<int>())).ReturnsAsync("2023-01-01T00:00:00Z");
            mockTokenRequestHandler.Setup(x => x.FetchDataWithTokenAsync("test-access-token", "json", "2023-01-01T00:00:00Z")).ReturnsAsync("{\"Report_Entry\": []}");

            // Act

            await lambdaHandler.Handler();

            // Assert

            mockTokenRequestHandler.Verify(x => x.FetchTokenAsync(), Times.Once);
            mockDynamoDBHelper.Verify(x => x.IsTableEmptyAsync(It.IsAny<int>()), Times.Once);
            mockTokenRequestHandler.Verify(x => x.FetchDataWithTokenAsync("test-access-token", "json", "2023-01-01T00:00:00Z"), Times.Once);
            mockProcessWorkdayMessage.Verify(x => x.ProcessWorkdayMessages(It.IsAny<Dictionary<string, WorkdayMessageKey>>()), Times.Once);

        }

        [Fact]
        public async Task Handler_DuplicateRecordsScenario()
        {
            // Arrange
            mockTokenRequestHandler.Setup(x => x.FetchTokenAsync()).ReturnsAsync("{\"access_token\": \"test-access-token\"}");
            mockDynamoDBHelper.Setup(x => x.IsTableEmptyAsync(It.IsAny<int>())).ReturnsAsync("2023-01-01T00:00:00Z");
            mockTokenRequestHandler.Setup(x => x.FetchDataWithTokenAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync("{\"Report_Entry\": [{\"CardNumber\": \"123\", \"LastUpdated\": \"2023-01-02T00:00:00Z\"}, {\"CardNumber\": \"123\", \"LastUpdated\": \"2023-01-03T00:00:00Z\"}]}");

            // Act
            await lambdaHandler.Handler();

            // Assert
            mockProcessWorkdayMessage.Verify(x => x.ProcessWorkdayMessages(It.Is<Dictionary<string, WorkdayMessageKey>>(dict => dict.Count == 1 && dict["123"].LastUpdated == "2023-01-03T00:00:00Z")), Times.Once);
        }


        [Fact]
        public async Task TestHandler_TokenRequestFailure()
        {
            // Arrange
            mockTokenRequestHandler.Setup(x => x.FetchTokenAsync()).ThrowsAsync(new Exception("Token request failed"));

            // Act
            var exception = await Record.ExceptionAsync(() => lambdaHandler.Handler());

            // Assert
            Assert.Null(exception);
        }

        [Fact]
        public async Task TestHandler_DataFetchFailure()
        {
            // Arrange
            mockTokenRequestHandler.Setup(x => x.FetchTokenAsync()).ReturnsAsync("{\"access_token\": \"test-access-token\"}");
            mockTokenRequestHandler.Setup(x => x.FetchDataWithTokenAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(new Exception("Data fetch failed"));

            // Act
            var exception = await Record.ExceptionAsync(() => lambdaHandler.Handler());

            // Assert
            Assert.Null(exception);
        }
    }
}

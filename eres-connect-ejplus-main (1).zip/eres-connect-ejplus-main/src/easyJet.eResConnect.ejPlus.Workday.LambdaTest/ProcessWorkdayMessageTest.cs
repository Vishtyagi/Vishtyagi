﻿using Amazon.S3.Model;
using Amazon.S3;
using easyJet.eResConnect.ejPlus.Core.PayLoad;
using easyJet.eResConnect.ejPlus.Core.Repository;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using easyJet.eResConnect.ejPlus.Workday.Lambda;

namespace easyJet.eResConnect.ejPlus.Workday.LambdaTest
{
    public class ProcessWorkdayMessageTest
    {

        private readonly Mock<ILogger<ProcessWorkdayMessage>> _mockLogger;
        private readonly Mock<IPlusCardWorkdayRepository> _mockPlusCardWorkdayRepository;
        private readonly Mock<IWorkdayMessagesUtil> _workdayMessagesUtil;
        private readonly Mock<IProcessWorkdayMessage> _processWorkdayMessageinterface;
        private readonly Mock<IDynamoDBHelper> _mockdynamoDBHelper;
        private readonly Mock<IAmazonS3> _mockS3Client;
        private readonly ProcessWorkdayMessage _processWorkdayMessage;

        public ProcessWorkdayMessageTest()
        {
            _mockLogger = new Mock<ILogger<ProcessWorkdayMessage>>();
            _mockPlusCardWorkdayRepository = new Mock<IPlusCardWorkdayRepository>();
            _workdayMessagesUtil = new Mock<IWorkdayMessagesUtil>();
            _mockdynamoDBHelper = new Mock<IDynamoDBHelper>();
            _mockS3Client = new Mock<IAmazonS3>();

            _processWorkdayMessage = new ProcessWorkdayMessage(_mockS3Client.Object, _mockLogger.Object, _mockPlusCardWorkdayRepository.Object, _workdayMessagesUtil.Object, _mockdynamoDBHelper.Object)
            {

                S3BucketName = "test-bucket",
            };

        }
        [Fact]
        public async Task ProcessWorkdayMessages_ValidMessages_NoErrors()
        {
            // Arrange
            var dict = new Dictionary<string, WorkdayMessageKey>
            {
                { "msg1", new WorkdayMessageKey { CardNumber = "123", FirstName = "John", LastName = "Doe", EmailAddress = "john.doe@example.com", WorkerDateEnd = "2070-01-01", LastUpdated = "2020-01-01T12:00:00"} }
             };
            var mockDataTable = new DataTable();
            mockDataTable.Columns.Add("CardNumber");
            mockDataTable.Columns.Add("FirstName");
            mockDataTable.Columns.Add("LastName");
            mockDataTable.Columns.Add("EmailAddress");
            mockDataTable.Columns.Add("WorkerDateEnd");
            mockDataTable.Columns.Add("AppStatus");
            mockDataTable.Columns.Add("LastUpdated");

            var row = mockDataTable.NewRow();
            row["CardNumber"] = "123";
            row["FirstName"] = "John";
            row["LastName"] = "Doe";
            row["EmailAddress"] = "john.doe@example.com";
            row["WorkerDateEnd"] = "2070-01-01";
            row["AppStatus"] = "Completed";
            row["LastUpdated"] = "2020-01-01T12:00:00";
            mockDataTable.Rows.Add(row);

            _workdayMessagesUtil.Setup(x => x.WorkdayMessagesValidation(It.IsAny<WorkdayMessageKey>())).Returns(new List<string>());
            _mockPlusCardWorkdayRepository.Setup(x => x.ConvertToDataTable(It.IsAny<List<WorkdayMessageKey>>())).Returns(mockDataTable);
            _mockPlusCardWorkdayRepository.Setup(x => x.ExecuteStoredProcedureWithDataTable(It.IsAny<DataTable>())).Returns(true);
            _mockS3Client.Setup(x => x.PutObjectAsync(It.IsAny<PutObjectRequest>(), default)).ReturnsAsync(new PutObjectResponse());
            _mockdynamoDBHelper.Setup(x => x.UpdateTimestampInDynamoDB());
            // Act
            var result = _processWorkdayMessage.ProcessWorkdayMessages(dict);

            // Assert
            _mockPlusCardWorkdayRepository.Verify(repo => repo.ConvertToDataTable(It.IsAny<List<WorkdayMessageKey>>()), Times.Once);
            _mockPlusCardWorkdayRepository.Verify(repo => repo.ExecuteStoredProcedureWithDataTable(It.IsAny<DataTable>()), Times.Once);
        }
        [Fact]
        public async Task ProcessWorkdayMessages_ValidMessages_ConvertToDataTable_ExceptionThown()
        {
            // Arrange
            var dict = new Dictionary<string, WorkdayMessageKey>
            {
                { "msg1", new WorkdayMessageKey { CardNumber = "123", FirstName = "John", LastName = "Doe", EmailAddress = "john.doe@example.com", WorkerDateEnd = "2070-01-01", LastUpdated = "2020-01-01T12:00:00"} }
             };

            _workdayMessagesUtil.Setup(x => x.WorkdayMessagesValidation(It.IsAny<WorkdayMessageKey>())).Returns(new List<string>());
            _mockPlusCardWorkdayRepository.Setup(x => x.ConvertToDataTable(It.IsAny<List<WorkdayMessageKey>>())).Throws(new Exception("Test Exception"));

            // Act
            await _processWorkdayMessage.ProcessWorkdayMessages(dict);

            // Assert
            _workdayMessagesUtil.Verify(util => util.WorkdayMessagesValidation(It.IsAny<WorkdayMessageKey>()), Times.Once);
            _mockPlusCardWorkdayRepository.Verify(repo => repo.ConvertToDataTable(It.IsAny<List<WorkdayMessageKey>>()), Times.Once);
        }
        [Fact]
        public async Task ProcessWorkdayMessages_ValidMessages_ExecuteStoredProcedureWithDataTable_ExceptionThown()
        {
            // Arrange
            var dict = new Dictionary<string, WorkdayMessageKey>
            {
                { "msg1", new WorkdayMessageKey { CardNumber = "123", FirstName = "John", LastName = "Doe", EmailAddress = "john.doe@example.com", WorkerDateEnd = "2070-01-01", LastUpdated = "2020-01-01T12:00:00"} }
             };
            var mockDataTable = new DataTable();
            mockDataTable.Columns.Add("CardNumber");
            mockDataTable.Columns.Add("FirstName");
            mockDataTable.Columns.Add("LastName");
            mockDataTable.Columns.Add("EmailAddress");
            mockDataTable.Columns.Add("WorkerDateEnd");
            mockDataTable.Columns.Add("AppStatus");
            mockDataTable.Columns.Add("LastUpdated");

            var row = mockDataTable.NewRow();
            row["CardNumber"] = "123";
            row["FirstName"] = "John";
            row["LastName"] = "Doe";
            row["EmailAddress"] = "john.doe@example.com";
            row["WorkerDateEnd"] = "2070-01-01";
            row["AppStatus"] = "Completed";
            row["LastUpdated"] = "2020-01-01T12:00:00";
            mockDataTable.Rows.Add(row);


            _workdayMessagesUtil.Setup(x => x.WorkdayMessagesValidation(It.IsAny<WorkdayMessageKey>())).Returns(new List<string>());
            _mockPlusCardWorkdayRepository.Setup(x => x.ConvertToDataTable(It.IsAny<List<WorkdayMessageKey>>())).Returns(mockDataTable);
            _mockPlusCardWorkdayRepository.Setup(x => x.ExecuteStoredProcedureWithDataTable(It.IsAny<System.Data.DataTable>())).Throws(new Exception("Test exception"));
            // Act
            await _processWorkdayMessage.ProcessWorkdayMessages(dict);

            // Assert
            _workdayMessagesUtil.Verify(util => util.WorkdayMessagesValidation(It.IsAny<WorkdayMessageKey>()), Times.Once);
            _mockPlusCardWorkdayRepository.Verify(repo => repo.ConvertToDataTable(It.IsAny<List<WorkdayMessageKey>>()), Times.Once);
            _mockPlusCardWorkdayRepository.Verify(repo => repo.ExecuteStoredProcedureWithDataTable(It.IsAny<DataTable>()), Times.Once);
        }

        [Fact]
        public async Task ProcessWorkdayMessages_ValidationFailure_MessagePushedToS3()
        {
            // Arrange
            var dict = new Dictionary<string, WorkdayMessageKey>
            {
                { "msg1", new WorkdayMessageKey { CardNumber = "123", FirstName = "John", LastName = "Doe", EmailAddress = "john.doe@example.com", WorkerDateEnd = "2070-01-01", LastUpdated = "2020-01-01T12:00:00"} }
             };
            _workdayMessagesUtil.Setup(util => util.WorkdayMessagesValidation
            (It.IsAny<WorkdayMessageKey>())).Returns(new List<string> { "Error" });
            _mockS3Client.Setup(x => x.PutObjectAsync(It.IsAny<PutObjectRequest>(), default)).ReturnsAsync(new PutObjectResponse());

            // Act
            await _processWorkdayMessage.ProcessWorkdayMessages(dict);

            // Assert
            _workdayMessagesUtil.Verify(util => util.WorkdayMessagesValidation(It.IsAny<WorkdayMessageKey>()), Times.Once);
            _mockS3Client.Verify(s => s.PutObjectAsync(It.IsAny<PutObjectRequest>(), default), Times.Once);

        }
        [Fact]
        public async Task ProcessWorkdayMessages_ExceptionThrown_ErrorLogged()
        {
            // Arrange
            var validMessage = new WorkdayMessageKey
            {
                CardNumber = "123",
                FirstName = "John",
                LastName = "Doe",
                EmailAddress = "john.doe@example.com",
                WorkerDateEnd = "2070-01-01",
                LastUpdated = "2020-01-01T12:00:00"
            };
            var messages = new Dictionary<string, WorkdayMessageKey>
            {
                { "message1", validMessage }
            };

            _workdayMessagesUtil.Setup(util => util.WorkdayMessagesValidation(It.IsAny<WorkdayMessageKey>()))
            .Throws(new Exception("Test exception"));

            // Act
            await _processWorkdayMessage.ProcessWorkdayMessages(messages);

            // Assert
            _workdayMessagesUtil.Verify(util => util.WorkdayMessagesValidation(It.IsAny<WorkdayMessageKey>()), Times.Once);
        }

        [Fact]
        public void GenerateFailureJson_ValidInput_ReturnsCorrectJson()
        {
            // Arrange
            var sqsMessages = new List<WorkdayMessageKey>
            {
                new WorkdayMessageKey { CardNumber = "123", FirstName = "John", LastName = "Doe", EmailAddress = "john.doe@example.com", WorkerDateEnd = "2070-01-01", LastUpdated = "2020-01-01T12:00:00" }
            };
            var failureReasons = new List<string> { "Error" };

            // Act
            var result = _processWorkdayMessage.GenerateFailureJson(sqsMessages, failureReasons);

            // Assert
            Assert.NotNull(result);
            var deserializedResult = JsonConvert.DeserializeObject<dynamic>(result);
            Assert.Equal("123", (string)deserializedResult.original_message[0].CardNumber);
        }

        [Fact]
        public void GenerateFailureJson_InvalidInput_ThrowsException()
        {
            // Arrange
            List<WorkdayMessageKey> sqsMessages = null; // Invalid input
            var failureReasons = new List<string> { "Error" };
            //Act
            var result = _processWorkdayMessage.GenerateFailureJson(sqsMessages, failureReasons);

            //Assert 
            Assert.NotNull(result);

            var deserializedResult = JsonConvert.DeserializeObject<dynamic>(result);
            Assert.Equal(null, (string)deserializedResult.original_message);

        }

        [Fact]
        public async Task StoreFailureMessagesInS3_ValidJson_Success()
        {
            // Arrange
            var failureJson = "{}";
            _mockS3Client.Setup(x => x.PutObjectAsync(It.IsAny<PutObjectRequest>(), default)).ReturnsAsync(new PutObjectResponse());
            string cardNumber = "S1235u";
            // Act
            await _processWorkdayMessage.StoreFailureMessagesInS3(failureJson,cardNumber);

            // Assert
            _mockS3Client.Verify(s => s.PutObjectAsync(It.Is<PutObjectRequest>(req =>
                req.BucketName == "test-bucket" &&
                req.ContentBody == failureJson &&
                req.ContentType == "application/json" &&
                req.Key.StartsWith("Workday/failed-Workday-")), default), Times.Once);
        }

        [Fact]
        public async Task StoreFailureMessagesInS3_InvalidJson_ThrowsException()
        {
            // Arrange
            var failureJson = "{ invalid json";
            _mockS3Client.Setup(x => x.PutObjectAsync(It.IsAny<PutObjectRequest>(), default)).ThrowsAsync(new AmazonS3Exception("Invalid JSON"));
            string cardNumber = "S1235u";
            // Act
            await _processWorkdayMessage.StoreFailureMessagesInS3(failureJson, cardNumber);

            // Assert
            _mockS3Client.Verify(s => s.PutObjectAsync(It.Is<PutObjectRequest>(req =>
                req.BucketName == "test-bucket" &&
                req.ContentBody == failureJson &&
                req.ContentType == "application/json" &&
                req.Key.StartsWith("Workday/failed-Workday-")), default), Times.Once);

        }
    }
}

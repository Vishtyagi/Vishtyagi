﻿using Amazon.DynamoDBv2;
using Amazon.Lambda.Core;
using Amazon.S3;
using easyJet.eResConnect.ejPlus.Core.Repository;
using easyJet.eResConnect.ejPlus.Workday.Lambda;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace easyJet.eResConnect.ejPlus.Workday.LambdaTest
{
    public class TokenRequestHandlerTest
    {
        private readonly Mock<ILogger<TokenRequestHandler>> _mockLogger;
        private readonly Mock<ILambdaContext> _mockContext;
        private readonly TokenRequestHandler _tokenRequestHandler;
        private readonly HttpClient _mockHttpClient;
        private readonly Mock<HttpMessageHandler> _mockHandler;

        private const string TokenEndPoint = "https://example.com/token";
        private const string ClientID = "test-client-id";
        private const string ClientSecret = "test-client-secret";
        private const string RefreshToken = "test-refresh-token";
        private const string DataEndPoint = "http://example.com/data-endpoint";

        public TokenRequestHandlerTest() 
        {
            _mockLogger = new Mock<ILogger<TokenRequestHandler>>();
            _mockContext = new Mock<ILambdaContext>();
            //_mockHttpClient = new Mock<HttpClient>();
            _mockHandler = new Mock<HttpMessageHandler>();
            _mockHttpClient = new HttpClient(_mockHandler.Object);
            _tokenRequestHandler = new TokenRequestHandler(_mockHttpClient, _mockLogger.Object)
            {
              
            };

            _tokenRequestHandler.ClientID = ClientID;
            _tokenRequestHandler.ClientSecret = ClientSecret;
            _tokenRequestHandler.RefreshToken = RefreshToken;
            _tokenRequestHandler.TokenEndPoint = TokenEndPoint;
            _tokenRequestHandler.DataEndPoint = DataEndPoint;   
        }
        [Fact]
        public async Task FetchTokenAsync_Success()
        {
            // Arrange

            var responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{\"access_token\":\"test-access-token\"}", Encoding.UTF8, "application/json")
            };

            HttpRequestMessage capturedRequest = null;

            _mockHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .Callback<HttpRequestMessage, CancellationToken>((request, cancellationToken) =>
                {
                    capturedRequest = request;
                })
                .ReturnsAsync(responseMessage);

            // Act
            var result = await _tokenRequestHandler.FetchTokenAsync();

            // Assert
            Assert.Contains("test-access-token", result);
        }

        [Fact]
        public async Task TestFetchTokenAsync_ExceptionHandling()
        {
            // Arrange

            // Simulate an exception in the mock handler
            _mockHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ThrowsAsync(new HttpRequestException("Simulated exception"));

            // Act
            var result = await _tokenRequestHandler.FetchTokenAsync();

            // Assert
            Assert.Empty(result); 

        }

        [Fact]
        public async Task TestFetchDataWithTokenAsync_Success()
        {
            // Arrange
            var accessToken = "test-access-token";
            var format = "json";
            var timestamp = "2024-07-22T10:00:00Z";
            var expectedResponseContent = "{\"data\":\"test-data\"}";

            var responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(expectedResponseContent, Encoding.UTF8, "application/json")
            };

            HttpRequestMessage capturedRequest = null;

            _mockHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .Callback<HttpRequestMessage, CancellationToken>((request, cancellationToken) =>
                {
                    capturedRequest = request;
                })
                .ReturnsAsync(responseMessage);

            // Act
            var result = await _tokenRequestHandler.FetchDataWithTokenAsync(accessToken, format, timestamp);

            // Assert
            Assert.NotNull(capturedRequest);
            Assert.Equal(HttpMethod.Get, capturedRequest.Method); // Ensure HTTP method is GET
            Assert.Equal($"{DataEndPoint}?format={Uri.EscapeDataString(format)}&timestamp={Uri.EscapeDataString(timestamp)}", capturedRequest.RequestUri.ToString()); // Ensure URL is correct
            Assert.Equal($"Bearer {accessToken}", capturedRequest.Headers.Authorization?.ToString()); // Ensure Authorization header is correct

            Assert.Equal(expectedResponseContent, result); // Ensure the response content is correctly returned
        }

        [Fact]
        public async Task TestFetchDataWithTokenAsync_ExceptionHandling()
        {
            // Arrange
            var accessToken = "test-access-token";
            var format = "json";
            var timestamp = "2024-07-22T10:00:00Z";

            // Simulate an exception in the mock handler
            _mockHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ThrowsAsync(new HttpRequestException("Simulated exception"));

            // Act
            var result = await _tokenRequestHandler.FetchDataWithTokenAsync(accessToken, format, timestamp);

            // Assert
            Assert.Empty(result); 
        }
    }
}

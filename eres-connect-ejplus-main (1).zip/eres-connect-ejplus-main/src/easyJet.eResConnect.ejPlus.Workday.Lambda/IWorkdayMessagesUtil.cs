﻿using easyJet.eResConnect.ejPlus.Core.PayLoad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace easyJet.eResConnect.ejPlus.Workday.Lambda
{
    public interface IWorkdayMessagesUtil
    {
         List<string> WorkdayMessagesValidation(WorkdayMessageKey workdayMessage);
    }

}

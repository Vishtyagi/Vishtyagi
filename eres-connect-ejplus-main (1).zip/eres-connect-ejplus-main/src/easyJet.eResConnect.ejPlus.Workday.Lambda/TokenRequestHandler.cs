﻿
using Amazon.Runtime;
using Microsoft.Extensions.Logging;

namespace easyJet.eResConnect.ejPlus.Workday.Lambda
{
    public class TokenRequestHandler: ITokenRequestHandler
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<TokenRequestHandler> _logger;
        public string ClientID { get; set; }
        public string ClientSecret { get; set; }
        public string RefreshToken { get; set; }
        public string TokenEndPoint { get; set; }
        public string DataEndPoint { get; set; }

        public TokenRequestHandler(HttpClient httpClient, ILogger<TokenRequestHandler> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
        }
        public async Task<string> FetchTokenAsync()
        {
            string result = string.Empty;
            try
            {   
                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, TokenEndPoint);
                    
                var parameters = new Dictionary<string, string>
                {
                    { "client_id", ClientID },
                    { "client_secret", ClientSecret },
                    { "refresh_token", RefreshToken },
                    { "grant_type", "refresh_token" }
                };

                request.Content = new FormUrlEncodedContent(parameters);

                HttpResponseMessage response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsStringAsync();
                }
                else
                {
                    // Log the error status code
                    _logger.LogError($"Error: Received HTTP status code {response.StatusCode} with reason {response.ReasonPhrase}");
                    return result;
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while getting access token from TokenEndPoint api.");
                return result;
            }
        }

        public  async Task<string> FetchDataWithTokenAsync(string accessToken, string format, string timestamp)
        {
            string responseContent = string.Empty;
            try
            {
                //_httpClient.Timeout = TimeSpan.FromSeconds(TimeOut);
                var queryString = $"?format={Uri.EscapeDataString(format)}&timestamp={Uri.EscapeDataString(timestamp)}";

                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, DataEndPoint + queryString);

                request.Headers.Add("Authorization", $"Bearer {accessToken}");

                HttpResponseMessage response = await _httpClient.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    return responseContent = await response.Content.ReadAsStringAsync();
                }
                else
                {
                    // Log the error status code
                    _logger.LogError($"Error On DataEndPoint : Received HTTP status code {response.StatusCode} with reason {response.ReasonPhrase}");
                    return responseContent; 
                }
            }
            catch(Exception ex) 
            {
                _logger.LogError(ex, "Error while getting EJPlus members data from Workday DataEndPoint api.");
                return responseContent;
            }
        }
    }
}

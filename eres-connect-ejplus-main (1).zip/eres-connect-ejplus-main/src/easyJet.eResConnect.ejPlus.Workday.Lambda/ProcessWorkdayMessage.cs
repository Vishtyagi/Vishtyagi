﻿using Amazon.S3;
using Amazon.S3.Model;
using easyJet.eResConnect.ejPlus.Core.PayLoad;
using easyJet.eResConnect.ejPlus.Core.Repository;
using Microsoft.Extensions.Logging;
using System.Data;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace easyJet.eResConnect.ejPlus.Workday.Lambda
{
    public class ProcessWorkdayMessage : IProcessWorkdayMessage
    {
        private readonly ILogger<ProcessWorkdayMessage> _logger;
        private readonly IPlusCardWorkdayRepository _plusCardWorkdayRepository;
        private readonly IWorkdayMessagesUtil _workdayMessagesUtil;
        private readonly IDynamoDBHelper _dynamoDBHelper;
        public string S3BucketName { get; set; }
        private readonly IAmazonS3 _s3Client;
        public ProcessWorkdayMessage(IAmazonS3 s3Client, ILogger<ProcessWorkdayMessage> logger, IPlusCardWorkdayRepository plusCardWorkdayRepository, IWorkdayMessagesUtil workdayMessagesUtil, IDynamoDBHelper dynamoDBHelper)
        {
            _s3Client = s3Client;
            this._logger = logger;
            this._plusCardWorkdayRepository = plusCardWorkdayRepository;
            this._workdayMessagesUtil = workdayMessagesUtil;
            this._dynamoDBHelper = dynamoDBHelper;
        }

        public async Task ProcessWorkdayMessages(Dictionary<string, WorkdayMessageKey> dict) 
        {
            try
            {
                var validRecords = new List<WorkdayMessageKey>();
                var validationFailurerecord = new List<WorkdayMessageKey>();
                foreach (var item in dict)
                {
                    WorkdayMessageKey workdayMessage = item.Value;
                    var failureRecord = _workdayMessagesUtil.WorkdayMessagesValidation(workdayMessage);
                    if (failureRecord.Count > 0)
                    {

                        var failureJson = GenerateFailureJson(new List<WorkdayMessageKey> { workdayMessage}, failureRecord);
                        await StoreFailureMessagesInS3(failureJson, workdayMessage.CardNumber);
                        validationFailurerecord.Add(workdayMessage);
                    }
                    else
                    {
                        validRecords.Add(workdayMessage);   
                    }
                    
                }
                if (validationFailurerecord.Count > 0)
                {
                    _logger.LogInformation("For Workday Total " + validationFailurerecord.Count + " Validation Failure messages pushed to S3 bucket.");
                }
                if (validRecords.Count > 0)
                {
                    DataTable dataTable = _plusCardWorkdayRepository.ConvertToDataTable(validRecords);
                    bool isSPExecutedSuccessfully = _plusCardWorkdayRepository.ExecuteStoredProcedureWithDataTable(dataTable);
                    if (isSPExecutedSuccessfully)
                    {
                        _dynamoDBHelper.TableName = "Workday";
                        _dynamoDBHelper.KeyName = "TimeStampID";
                        _dynamoDBHelper.KeyAttribute = "TimeStamp";
                        await _dynamoDBHelper.UpdateTimestampInDynamoDB();
                    }
                    else
                    {
                        _logger.LogInformation("Timestamp value is not updated into Dynamo DB table.");
                    }
                }
                
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while processing Workday Data.");
            }
          
        }
        public string GenerateFailureJson(List<WorkdayMessageKey> workdayMessages, List<string> failureReasons)
        {
            var originalMessage = workdayMessages;
            var failureReason = string.Join("\n", failureReasons);
            var failedAt = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss");

            var failureDetails = new
            {
                original_message = originalMessage,
                failure_metadata = new
                {
                    failure_reason = failureReason,
                    failed_at = failedAt
                }
            };

            var jsonOptions = new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            };

            return JsonSerializer.Serialize(failureDetails, jsonOptions);
        }

        public async Task StoreFailureMessagesInS3(string failureJson, string cardNumber)
        {
            _logger.LogInformation("Attempting to store Failure messages into Workday S3 bucket.");
            string timestamp = DateTime.UtcNow.ToString("yyyyMMddTHHmmss");
            string fileName = $"Workday/failed-Workday-{timestamp}-{cardNumber}.json";

            var putRequest = new PutObjectRequest
            {
                BucketName = S3BucketName,
                Key = fileName,
                ContentBody = failureJson,
                ContentType = "application/json"
            };
            try
            {
                var response = await _s3Client.PutObjectAsync(putRequest);
                _logger.LogInformation($"Failure record sent to Workday S3 bucket :{fileName} with original Message and Failure reason: {response}.");
            }
            catch (Exception s3bucketException)
            {
                _logger.LogError(s3bucketException, "Failed to send record to workday  S3 bucket.");
            }

        }
    }
}

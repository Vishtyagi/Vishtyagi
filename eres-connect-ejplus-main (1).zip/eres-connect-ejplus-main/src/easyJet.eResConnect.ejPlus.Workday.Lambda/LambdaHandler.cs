﻿using Amazon.Lambda.RuntimeSupport;
using easyJet.eResConnect.ejPlus.Core.Repository;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using easyJet.eResConnect.ejPlus.Core.PayLoad;

namespace easyJet.eResConnect.ejPlus.Workday.Lambda
{
    public class LambdaHandler : BackgroundService
    {
        private readonly ILogger<LambdaHandler> logger;
        private readonly IConfiguration _configuration;
        private readonly IProcessWorkdayMessage _processWorkdayMessage;
        private readonly IPlusCardWorkdayRepository _plusCardWorkdayRepository;
        private readonly ITokenRequestHandler _tokenRequestHandler;
        private readonly IDynamoDBHelper _dynamoDBHelper;

        public LambdaHandler(ILogger<LambdaHandler> logger, IConfiguration configuration, IPlusCardWorkdayRepository plusCardWorkdayRepository, IProcessWorkdayMessage processWorkdayMessage, ITokenRequestHandler tokenRequestHandler,IDynamoDBHelper dynamoDBHelper)
        {
            this.logger = logger;
            this._configuration = configuration;
            this._processWorkdayMessage = processWorkdayMessage;    
            this._plusCardWorkdayRepository = plusCardWorkdayRepository;
            this._tokenRequestHandler = tokenRequestHandler;
            this._dynamoDBHelper = dynamoDBHelper;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var handler = Handler;
            return LambdaBootstrapBuilder.Create(handler)
                .Build()
                .RunAsync(stoppingToken);
           
        }
        public async Task Handler()
        {
            _tokenRequestHandler.ClientID = _configuration["ClientID"];
            _tokenRequestHandler.ClientSecret = _configuration["ClientSecret"];
            _tokenRequestHandler.RefreshToken = _configuration["RefreshToken"];
            _tokenRequestHandler.TokenEndPoint = _configuration["TokenEndPoint"];
            _tokenRequestHandler.DataEndPoint = _configuration["DataEndPoint"];

            int daysToSubtract = Convert.ToInt32(_configuration["PreviousDays"]);

            _processWorkdayMessage.S3BucketName = _configuration["InvalidRecordBucket"];
            _plusCardWorkdayRepository.ConnectionString = _configuration.GetConnectionString("eResReservation");

            _dynamoDBHelper.TableName = _configuration["WorkdayTableKey:WorkdayTableName"];
            _dynamoDBHelper.KeyName = _configuration["WorkdayTableKey:WorkdayKeyName"];
            _dynamoDBHelper.KeyAttribute = _configuration["WorkdayTableKey:WorkdayKeyAttribute"];
            try
            {


                string tokenResponse = await _tokenRequestHandler.FetchTokenAsync();

                if (string.IsNullOrEmpty(tokenResponse))
                {
                    logger.LogError("Failed to fetch token: Response is empty.");
                    return;
                }
                string accessToken = string.Empty;
                try
                {
                    // Parse the token response to get the access token
                    var tokenData = JsonSerializer.Deserialize<Dictionary<string, string>>(tokenResponse);
                    if (tokenData != null && tokenData.TryGetValue("access_token", out var token))
                    {
                        accessToken = token;
                    }
                    else
                    {
                        logger.LogError("Failed to parse access token from response.");
                        return;
                    }
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Failed to deserialize the token data.");
                    return;
                }

                // Step 2: Use the access token and Timestamp to fetch data from another endpoint
                string format = "json";
                string deltaTimeStamp = await _dynamoDBHelper.IsTableEmptyAsync(daysToSubtract);

                if (string.IsNullOrEmpty(deltaTimeStamp))
                {
                    logger.LogError("Failed to retrieve timestamp from DynamoDB: Response is empty.");
                    return;
                }

                string dataResponse = await _tokenRequestHandler.FetchDataWithTokenAsync(accessToken, format, deltaTimeStamp);
                if (string.IsNullOrEmpty(dataResponse))
                {
                    logger.LogError("Failed to fetch data: Response is empty.");
                    return;
                }

                Dictionary<string, WorkdayMessageKey> dict = new Dictionary<string, WorkdayMessageKey>();

                using (JsonDocument document = JsonDocument.Parse(dataResponse))
                {
                    JsonElement root = document.RootElement;
                    JsonElement reportEntries = root.GetProperty("Report_Entry");

                    foreach (JsonElement entryElement in reportEntries.EnumerateArray())
                    {
                        WorkdayMessageKey tempKey = new WorkdayMessageKey();
                        try
                        {
                            var options = new JsonSerializerOptions
                            {
                                PropertyNameCaseInsensitive = true
                            };

                            var workdayMessageKeys = JsonSerializer.Deserialize<WorkdayMessageKey>(entryElement, options);
                            if (workdayMessageKeys != null)
                            {
                                if (dict.ContainsKey(workdayMessageKeys.CardNumber))
                                {
                                    dict.TryGetValue(workdayMessageKeys.CardNumber, out tempKey);
                                    if (DateTime.Compare(Convert.ToDateTime(tempKey.LastUpdated), Convert.ToDateTime(workdayMessageKeys.LastUpdated)) < 0)
                                    {

                                        dict[workdayMessageKeys.CardNumber] = workdayMessageKeys;
                                        logger.LogInformation("Found Duplicate CardNumber " + workdayMessageKeys.CardNumber + " records in batch.");
                                    }
                                }
                                else
                                {
                                    dict[workdayMessageKeys.CardNumber] = workdayMessageKeys;
                                }
                            }
                            else
                            {
                                logger.LogError("Message has no data.");
                            }

                        }
                        catch (Exception ex)
                        {
                            logger.LogError(ex, "Failed to deserialize Workday data");
                        }
                    }
                }

                var result = _processWorkdayMessage.ProcessWorkdayMessages(dict);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "An unexpected error occurred while processing data.");
            }
        }
    }
}

﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace easyJet.eResConnect.ejPlus.Workday.Lambda
{
    public class DynamoDBHelper : IDynamoDBHelper
    {
        private readonly IAmazonDynamoDB _dynamoDb;
        private readonly ILogger<DynamoDBHelper> _logger;
        public string TableName { get; set; }
        public string KeyName { get; set; }
        public string KeyAttribute { get; set; }
        public DynamoDBHelper(IAmazonDynamoDB dynamoDb, ILogger<DynamoDBHelper> logger)
        {
            _dynamoDb = dynamoDb;
            _logger = logger;
        }
        public async Task<string> IsTableEmptyAsync(int daysToSubtract)
        {
            string finalTimestamp = string.Empty;
            try
            {
                var scanRequest = new ScanRequest
                {
                    TableName = TableName,
                    Limit = 1

                };
                var response = await _dynamoDb.ScanAsync(scanRequest);

                if (response.Items.Count == 0)
                {
                    string currentTimeStamp = Convert.ToString(DateTime.UtcNow);
                    finalTimestamp = AdjustTimestamp(currentTimeStamp, daysToSubtract);
                    _logger.LogInformation("DynamoDB WorkdayTable is empty, pick " + finalTimestamp + " current timestamp.");
                }
                else
                {
                    //Table is not empty, pick timestamp from DynamoDB
                    string timestampValue = response.Items[0][KeyAttribute].S;

                    DateTime dateValue;

                    // Parse date
                    if (DateTime.TryParseExact(timestampValue.Replace("T", " "), "u", CultureInfo.InvariantCulture,
                                               DateTimeStyles.RoundtripKind, out dateValue)) 
                    {
                        dateValue = dateValue.AddMinutes(-1);
                        finalTimestamp = dateValue.ToString("yyyy-MM-ddTHH:mm:ssZ");
                        _logger.LogInformation("DynamoDB WorkdayTable is not empty, pick " + finalTimestamp + " latest timestamp from table.");

                    }
                    else
                    {
                        _logger.LogError( "Unable to parse the timestamp.");
                    }

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unable to fetch response from the DynamoDB WorkdayTable.");
            }
            return finalTimestamp;
        }

        public string AdjustTimestamp(string timestamp, int daysToSubtract)
        {

            string adjustedTimestamp = string.Empty;
            try
            {
                if (DateTime.TryParse(timestamp, out DateTime parsedTimestamp))
                {
                    parsedTimestamp = parsedTimestamp.AddDays(-daysToSubtract);

                    // Ensure it has the Z marker for UTC
                    adjustedTimestamp = parsedTimestamp.ToString("yyyy-MM-ddTHH:mm:ssZ");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unable to parse the timestamp.");
            }
            return adjustedTimestamp;
        }
        public async Task UpdateTimestampInDynamoDB()
        {
            try
            {
                var item = new Dictionary<string, AttributeValue>
                {
                    { KeyName, new AttributeValue { N = "0" } },
                    { KeyAttribute, new AttributeValue { S = DateTime.UtcNow.ToString("u").Replace(" ", "T") } } // Set new timestamp
                };

                // Create the PutItem request
                var putRequest = new PutItemRequest
                {
                    TableName = TableName,
                    Item = item
                };
                var result = await _dynamoDb.PutItemAsync(putRequest);
                _logger.LogInformation("Timestamp value is updated into Dynamo DB WorkdayTable.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while updating timestamp value on dynamoDB WorkdayTable.");
            }
        }
    }
}

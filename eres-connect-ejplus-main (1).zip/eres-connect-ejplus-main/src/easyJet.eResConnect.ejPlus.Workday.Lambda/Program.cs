﻿
using Amazon.DynamoDBv2;
using Amazon.S3;
using easyJet.AWS.Configuration;
using easyJet.eResConnect.ejPlus.Core.Repository;
using easyJet.eResConnect.ejPlus.Workday.Lambda;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

var builder = Host.CreateApplicationBuilder(args);

// Configuration from environment
builder.Configuration.AddEnvironmentVariables();

// TOOD: secrets manager/parameter store
builder.Configuration.AddSecretsAndSystemsManager("/ejplus/workday/");
//logging
builder.Services.AddLogging(loggingBuilder =>
{
    loggingBuilder.ClearProviders();
    loggingBuilder.AddConsole();
});
builder.Services.AddSingleton<IConfiguration>(builder.Configuration);
builder.Services.AddHttpClient();
builder.Services.ConfigureHttpClientDefaults(httpClientBuilder =>
    {
        httpClientBuilder.ConfigureHttpClient(httpClient =>
        {
            httpClient.Timeout = TimeSpan.FromSeconds(Convert.ToInt32(builder.Configuration["TimeOut"]));
        });
    });
builder.Services.AddTransient<ITokenRequestHandler, TokenRequestHandler>();
builder.Services.AddTransient<IProcessWorkdayMessage, ProcessWorkdayMessage>();
builder.Services.AddSingleton<IPlusCardWorkdayRepository, PlusCardWorkdayRepository>();
builder.Services.AddTransient<IWorkdayMessagesUtil, WorkdayMessagesUtil>();
builder.Services.AddTransient<IDynamoDBHelper, DynamoDBHelper>();

//// Configure services
builder.Services.AddSingleton<IAmazonS3, AmazonS3Client>();
builder.Services.AddSingleton<IAmazonDynamoDB, AmazonDynamoDBClient>();
builder.Services.AddHostedService<LambdaHandler>();

var app = builder.Build();

app.Run();
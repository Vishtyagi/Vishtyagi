﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace easyJet.eResConnect.ejPlus.Workday.Lambda
{
    public interface ITokenRequestHandler
    {
        string ClientID { get; set; }
        string ClientSecret { get; set; }
        string RefreshToken { get; set; }
        string TokenEndPoint { get; set; }
        string DataEndPoint { get; set; }
        Task<string> FetchTokenAsync();
        Task<string> FetchDataWithTokenAsync(string accessToken, string format, string timestamp);
    }
}

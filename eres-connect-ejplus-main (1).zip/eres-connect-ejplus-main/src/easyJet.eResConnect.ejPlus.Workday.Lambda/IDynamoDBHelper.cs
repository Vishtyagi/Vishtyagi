﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace easyJet.eResConnect.ejPlus.Workday.Lambda
{
    public interface IDynamoDBHelper
    {
        string TableName { get; set; }
        string KeyName { get; set; }
        string KeyAttribute { get; set; }
        Task<string> IsTableEmptyAsync(int daysToSubtract);
        string AdjustTimestamp(string timestamp, int daysToSubtract);
        Task UpdateTimestampInDynamoDB();
    }
}

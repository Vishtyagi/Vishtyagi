﻿using Amazon.Runtime.Internal.Util;
using easyJet.eResConnect.ejPlus.Core.PayLoad;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace easyJet.eResConnect.ejPlus.Workday.Lambda
{
    public class WorkdayMessagesUtil : IWorkdayMessagesUtil
    {
        private readonly ILogger<WorkdayMessagesUtil> _logger;
        public WorkdayMessagesUtil(ILogger<WorkdayMessagesUtil> logger)
        {
            _logger = logger;
        }
        public List<string> WorkdayMessagesValidation(WorkdayMessageKey workdayMessage)
        {
            var ValidationFailureMessages = new List<string>();

            var minSmallDateTime = new DateTime(1900, 1, 1);
            var maxSmallDateTime = new DateTime(2079, 6, 6);
            bool validationFlag = true;

            try
            {
                _logger.LogInformation("Starting validation on Workday data received from DataEndPoint.");
                if(validationFlag && string.IsNullOrEmpty(workdayMessage.CardNumber))
                {
                    ValidationFailureMessages.Add("CardNumber is a mandatory Field.");
                    validationFlag = false;
                }
                if(validationFlag && workdayMessage.CardNumber.Length > 20)
                {
                    ValidationFailureMessages.Add("CardNumber cannot have more then 20 characters.");
                    validationFlag = false;
                }
                if (validationFlag && string.IsNullOrEmpty(workdayMessage.FirstName))
                {
                    ValidationFailureMessages.Add("first_name is a mandatory Field.");
                    validationFlag = false;
                }

                if (validationFlag && workdayMessage.FirstName.Length > 50)
                {
                    workdayMessage.FirstName = workdayMessage.FirstName.Substring(0, 50);
                }

                if (validationFlag && string.IsNullOrEmpty(workdayMessage.LastName))
                {
                    ValidationFailureMessages.Add("last_name is a mandatory Field.");
                    validationFlag = false;
                }

                if (validationFlag && workdayMessage.LastName.Length > 50)
                {
                    workdayMessage.LastName = workdayMessage.LastName.Substring(0, 50);
                }

                if(validationFlag && string.IsNullOrEmpty(workdayMessage.EmailAddress))
                {
                    ValidationFailureMessages.Add("email is a mandatory Field.");
                    validationFlag = false;
                }
                if (validationFlag && workdayMessage.EmailAddress.Length > 50)
                {
                    workdayMessage.EmailAddress = workdayMessage.EmailAddress.Substring(0, 50);
                }
                if(validationFlag && string.IsNullOrEmpty(workdayMessage.WorkerDateEnd))
                {
                    workdayMessage.WorkerDateEnd = maxSmallDateTime.ToString();
                }
                if (validationFlag && !DateTime.TryParse(workdayMessage.WorkerDateEnd, out DateTime expiryDate))
                {
                    ValidationFailureMessages.Add("WorkerDateEnd should be in a format which can be converted into SmallDateTime.");
                    validationFlag = false;
                }
                if (validationFlag && Convert.ToDateTime(workdayMessage.WorkerDateEnd) > maxSmallDateTime)
                {
                    workdayMessage.WorkerDateEnd = maxSmallDateTime.ToString();
                }

                if (validationFlag && string.IsNullOrEmpty(workdayMessage.LastUpdated))
                {
                    ValidationFailureMessages.Add("LastUpdated is a mandatory Field.");
                    validationFlag = false;
                }
                if(validationFlag && !DateTime.TryParse(workdayMessage.LastUpdated, out DateTime parseTimedate))
                {
                    ValidationFailureMessages.Add("LastUpdated should be in a format which can be converted into DateTime.");
                    validationFlag = false;
                }
                _logger.LogInformation( "Successfully validated workday data without eny exception.");
            }
            catch (Exception ex) 
            {
                _logger.LogError(ex,"Error while validating Workday data.");
                
            }
            return ValidationFailureMessages;
        }
    }
}

﻿using Amazon.Lambda.Core;
using Amazon.Lambda.RuntimeSupport;
using Amazon.Lambda.Serialization.SystemTextJson;
using Amazon.Lambda.SQSEvents;
using Amazon.SQS.Model;
using Amazon.SQS;
using System.Text.Json;
using static Amazon.Lambda.SQSEvents.SQSBatchResponse;
using Amazon.Lambda.S3Events;
using CsvHelper.Configuration;
using easyJet.eResConnect.ejPlus.Core.PayLoad;
using Microsoft.Extensions.Configuration;
using easyJet.eResConnect.ejPlus.Core.Repository;
using Amazon.Extensions.Configuration.SystemsManager;
using Amazon.Lambda.CloudWatchEvents;
using System.Collections.Generic;

namespace easyJet.eResConnect.ejPlus.Zuora.Lambda;

public class LambdaHandler : BackgroundService
{
    private readonly ILogger<LambdaHandler> logger;
    private readonly IConfiguration _configuration;
    private readonly IAmazonSQS _sqsClient;
    private readonly IPlusCardZuoraSQSLambda _plusCardZuoraSQSLambda;
    private readonly IPlusCardZuoraRepository _plusCardZuoraRepository;

    public LambdaHandler(ILogger<LambdaHandler> logger, IAmazonSQS sqsClient, IConfiguration configuration, IPlusCardZuoraSQSLambda plusCardZuoraSQSLambda, IPlusCardZuoraRepository plusCardZuoraRepository)
    {
        this.logger = logger;
        this._sqsClient = sqsClient;
        this._configuration = configuration;
        _plusCardZuoraSQSLambda = plusCardZuoraSQSLambda;
        _plusCardZuoraRepository = plusCardZuoraRepository;
    }

    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var handler = Handler;
        return LambdaBootstrapBuilder.Create(handler, new SourceGeneratorLambdaJsonSerializer<SQSJsonSerializerContext>())
            .Build()
            .RunAsync(stoppingToken);
    }

    public async Task<SQSBatchResponse> Handler(SQSEvent evnt, ILambdaContext context)
    {
        using var scope = logger.BeginScope(new
        {
            context.AwsRequestId
        });

        _configuration.WaitForSystemsManagerReloadToComplete(TimeSpan.FromSeconds(2));


        var batchItemFailures = new List<BatchItemFailure>();

        if (evnt.Records == null)
        {
            logger.LogInformation("Received empty event");
            return new SQSBatchResponse(batchItemFailures);
        }
        var eventRecords = evnt.Records;

        logger.LogInformation($"New ${eventRecords.Count} records received with AwsRequestId ${context.AwsRequestId}.");

        Dictionary<string, SQSMessageKey> dict = new Dictionary<string, SQSMessageKey>();

        foreach (var record in eventRecords)
        {
            var sqsEvent = record.Body;
            SQSMessageKey tempKey = new SQSMessageKey();
            try
            {
                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };

                var cloudWatchEvent = JsonSerializer.Deserialize<CloudWatchEvent<SQSMessageDetail>>(sqsEvent, options);

                var sqsMessageDetail = cloudWatchEvent.Detail;

                if (sqsMessageDetail != null)
                {
                    var sqsMessageKeys = sqsMessageDetail.Data;

                    if (sqsMessageKeys != null)
                    {
                        if (dict.ContainsKey(sqsMessageKeys.MembershipId))
                        {
                            dict.TryGetValue(sqsMessageKeys.MembershipId, out tempKey);
                            if (DateTime.Compare(Convert.ToDateTime(tempKey.Timedate), Convert.ToDateTime(sqsMessageKeys.Timedate)) < 0)
                            {
                                sqsMessageKeys.SQSMessageID = record.MessageId;
                                dict[sqsMessageKeys.MembershipId] = sqsMessageKeys;
                                logger.LogInformation("Found Duplicate MembershipID " + sqsMessageKeys.MembershipId + " records in sqsEvent.");
                            }
                        }
                        else
                        {
                            sqsMessageKeys.SQSMessageID = record.MessageId;
                            dict[sqsMessageKeys.MembershipId] = sqsMessageKeys;

                        }
                    }
                    else
                    {
                        logger.LogError("Message has no data: " + record.MessageId);
                    }
                }
                else
                {
                    logger.LogError("Message has no detail: " + record.MessageId);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Failed to deserialize SQSEvent for MessageID:" + record.MessageId);
            }

        }
        _plusCardZuoraSQSLambda.S3BucketName = _configuration["InvalidRecordBucket"];
        _plusCardZuoraRepository.ConnectionString = _configuration.GetConnectionString("eResReservation");
         var sqsBatchResponse = await _plusCardZuoraSQSLambda.ProcessSQSMessages(dict);
        
        batchItemFailures.AddRange(sqsBatchResponse.BatchItemFailures);

        return new SQSBatchResponse(batchItemFailures);
    }

}


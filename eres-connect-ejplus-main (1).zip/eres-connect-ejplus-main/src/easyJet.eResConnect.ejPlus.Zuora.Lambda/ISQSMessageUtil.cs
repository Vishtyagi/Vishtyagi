﻿using easyJet.eResConnect.ejPlus.Core.PayLoad;

namespace easyJet.eResConnect.ejPlus.Zuora.Lambda
{
    public interface ISQSMessageUtil
    {
        List<string> SQSMessageValidatation(SQSMessageKey sqsMessageKey);
    }
}

﻿using Amazon.S3;
using Amazon.S3.Model;
using System.Data;
using System.Text.Json;
using easyJet.eResConnect.ejPlus.Core.Repository;
using easyJet.eResConnect.ejPlus.Core.PayLoad;
using System.Text.Encodings.Web;
using Amazon.Lambda.SQSEvents;
using static Amazon.Lambda.SQSEvents.SQSBatchResponse;
using static Amazon.Lambda.SQSEvents.SQSEvent;

namespace easyJet.eResConnect.ejPlus.Zuora.Lambda
{

    public class PlusCardZuoraSQSLambda : IPlusCardZuoraSQSLambda
    {
        private readonly ILogger<PlusCardZuoraSQSLambda> _logger;
        private readonly IPlusCardZuoraRepository _plusCardZuoraRepository;
        private readonly ISQSMessageUtil _sQSMessageUtil;
        public string S3BucketName { get; set; }
        private readonly IAmazonS3 _s3Client;
        public PlusCardZuoraSQSLambda(IAmazonS3 s3Client, ILogger<PlusCardZuoraSQSLambda> logger, IPlusCardZuoraRepository plusCardZuoraRepository, ISQSMessageUtil sQSMessageUtil)
        {
            _s3Client = s3Client;
            this._logger = logger;
            this._plusCardZuoraRepository = plusCardZuoraRepository;
            this._sQSMessageUtil = sQSMessageUtil;
        }

        public async Task<SQSBatchResponse> ProcessSQSMessages(Dictionary<string, SQSMessageKey> dict)
        {
            var batchItemFailures = new List<BatchItemFailure>();

            try
            {
                var validRecords = new List<SQSMessageKey>();
                var validationFailureRecord = new List<SQSMessageKey>();
                DataTable dataTable = new DataTable();
                foreach (var item in dict)
                {
                    SQSMessageKey sQSMessage = item.Value;
                    var validationFailure = _sQSMessageUtil.SQSMessageValidatation(sQSMessage);

                    if (validationFailure.Count > 0)
                    {
                        validationFailureRecord.Add(sQSMessage);
                        string sqsMessageid = sQSMessage.SQSMessageID;
                        var failureJson = GenerateFailureJson(new List<SQSMessageKey> { sQSMessage }, validationFailure);
                        await StoreFailureMessagesInS3(failureJson, sqsMessageid);
                    }
                    else
                    {
                        validRecords.Add(sQSMessage);
                    }
                }
                if (validationFailureRecord.Count > 0)
                {
                    _logger.LogInformation("Total " + validationFailureRecord.Count + " Validation Failure messages pushed to S3 bucket.");
                }

                if (validRecords.Count > 0)
                {
                    dataTable = _plusCardZuoraRepository.ConvertToDataTable(validRecords);
                    DataTable result = _plusCardZuoraRepository.ExecuteStoredProcedureWithDataTable(dataTable);

                    var resultFailureMessages = new List<string>();
                    var databaseFailureRecord = new List<SQSMessageKey>();
                    int databaseFailureCount = 0;
                    foreach (DataRow row in result.Rows)
                    {
                        if (row.ItemArray.Length > 2)
                        {
                            batchItemFailures.Add(new BatchItemFailure { ItemIdentifier = row[8].ToString() });
                        }
                        else
                        {
                            if (row[1] != DBNull.Value)
                            {
                                resultFailureMessages.Add(row[1].ToString());
                                foreach (var validRecord in validRecords)
                                {
                                    if (validRecord.SQSMessageID == row[0].ToString())
                                    {
                                        databaseFailureRecord.Add(validRecord);
                                        databaseFailureCount++;
                                    }
                                }
                                var sqsMessageid = row[0].ToString();
                                var resultFailureJson = GenerateFailureJson(databaseFailureRecord, resultFailureMessages);
                                await StoreFailureMessagesInS3(resultFailureJson, sqsMessageid);
                                resultFailureMessages.Clear();
                                databaseFailureRecord.Clear();
                            }
                        }
                    }
                    if(databaseFailureCount > 0)
                    {
                        _logger.LogInformation("Total " + databaseFailureCount + " Database Failure messages pushed to S3 bucket.");

                    }
                }
                validRecords.Clear();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while processing SQS Messages.");
            }
            if(batchItemFailures.Count > 0)
            {
                _logger.LogInformation("Total " + batchItemFailures.Count + " Transient messages received.");
            }
            return new SQSBatchResponse(batchItemFailures);
        }

        public string GenerateFailureJson(List<SQSMessageKey> sqsMessages, List<string> failureReasons)
        {
            var originalMessage = sqsMessages;
            var failureReason = string.Join("\n", failureReasons);
            var failedAt = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss");
            
            var failureDetails = new
            {
                original_message = originalMessage,
                failure_metadata = new
                {
                    failure_reason = failureReason,
                    failed_at = failedAt
                }
            };

            var jsonOptions = new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            };

            return JsonSerializer.Serialize(failureDetails, jsonOptions);
        }

        public async Task StoreFailureMessagesInS3(string failureJson, string sqsMessageID)
        {
            _logger.LogInformation("Attempting to store Failure messages into S3 bucket.");
            string timestamp = DateTime.UtcNow.ToString("yyyyMMddTHHmmss");

            string fileName = $"Zuora/failed-Zuora-{timestamp}-{sqsMessageID}.json";

            var putRequest = new PutObjectRequest
            {
                BucketName = S3BucketName,
                Key = fileName,
                ContentBody = failureJson,
                ContentType = "application/json"
            };
            try
            {
                var response = await _s3Client.PutObjectAsync(putRequest);
                _logger.LogInformation($"Failure record sent to S3 bucket :{fileName} with original Message and Failure reason: {response}.");
            }
            catch (Exception s3bucketException)
            {
                _logger.LogError(s3bucketException, "Failed to send record to S3 bucket.");
            }

        }
    }
}

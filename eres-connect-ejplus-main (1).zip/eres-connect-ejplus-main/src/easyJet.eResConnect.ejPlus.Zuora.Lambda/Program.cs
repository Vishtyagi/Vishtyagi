﻿using Amazon.S3;
using Amazon.SQS;
using easyJet.eResConnect.ejPlus.Core.Repository;
using easyJet.eResConnect.ejPlus.Zuora.Lambda;
using easyJet.AWS.Configuration;

var builder = Host.CreateApplicationBuilder(args);

// Configuration from environment
builder.Configuration.AddEnvironmentVariables();

// TOOD: secrets manager/parameter store
builder.Configuration.AddSecretsAndSystemsManager("/ejplus/zuora/");
//logging
builder.Services.AddLogging(loggingBuilder =>
{
    loggingBuilder.ClearProviders();
    loggingBuilder.AddConsole();
});
//builder.Services.AddSingleton<IConfiguration>(builder.Configuration);

builder.Services.AddTransient<IPlusCardZuoraSQSLambda, PlusCardZuoraSQSLambda>();
builder.Services.AddSingleton<IPlusCardZuoraRepository, PlusCardZuoraRepository>();
builder.Services.AddTransient<ISQSMessageUtil, SQSMessageUtil>();

// Configure services
builder.Services.AddSingleton<IAmazonSQS, AmazonSQSClient>();
builder.Services.AddSingleton<IAmazonS3, AmazonS3Client>();
builder.Services.AddHostedService<LambdaHandler>();

var app = builder.Build();

app.Run();
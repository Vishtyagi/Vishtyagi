﻿using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using static Amazon.Lambda.SQSEvents.SQSEvent;

namespace easyJet.eResConnect.ejPlus.Zuora.Lambda
{
    [DataContract]
    public class InvalidRecordMessage
    {
        [DataMember(Name = "originalMessage")]
        [JsonPropertyName("originalMessage")]
        public SQSMessage OriginalMessage { get; set; }

        [DataMember(Name = "failureReason")]
        [JsonPropertyName("failureReason")]

        public string FailureReason { get; set; }
    }
}

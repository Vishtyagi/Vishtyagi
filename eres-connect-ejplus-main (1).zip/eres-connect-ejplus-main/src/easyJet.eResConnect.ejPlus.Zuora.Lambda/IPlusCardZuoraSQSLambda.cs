﻿using Amazon.Lambda.SQSEvents;
using easyJet.eResConnect.ejPlus.Core.PayLoad;

namespace easyJet.eResConnect.ejPlus.Zuora.Lambda
{
    public interface IPlusCardZuoraSQSLambda
    {
        string S3BucketName { get; set; }
        Task<SQSBatchResponse> ProcessSQSMessages(Dictionary<string, SQSMessageKey> dict);
        string GenerateFailureJson(List<SQSMessageKey> sqsMessages, List<string> failureReasons);
        Task StoreFailureMessagesInS3(string failureJson,string sqsMessageID);
    }
}

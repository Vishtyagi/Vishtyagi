﻿using easyJet.eResConnect.ejPlus.Core.PayLoad;

namespace easyJet.eResConnect.ejPlus.Zuora.Lambda
{
    public class SQSMessageUtil : ISQSMessageUtil
    {
        public readonly ILogger<SQSMessageUtil> _logger;

        public SQSMessageUtil(ILogger<SQSMessageUtil> logger)
        {
            _logger = logger;
        }
        public List<string> SQSMessageValidatation(SQSMessageKey sqsMessageKey)
        {
            var ValidationFailureMessages = new List<string>();

            var minSmallDateTime = new DateTime(1900, 1, 1);
            var maxSmallDateTime = new DateTime(2079, 6, 6);
            bool validationFlag = true;
            try
            {
                _logger.LogInformation("Starting validation on SQSMessages received from SQS queue.");

                if (validationFlag && string.IsNullOrEmpty(sqsMessageKey.MembershipId))
                {
                    ValidationFailureMessages.Add("membership_id is a mandatory Field.");
                    validationFlag = false;
                }

                if (validationFlag && sqsMessageKey.MembershipId.Length > 20)
                {
                    ValidationFailureMessages.Add("membership_id cannot have more then 20 characters.");
                    validationFlag = false;
                }

                if (validationFlag && string.IsNullOrEmpty(sqsMessageKey.FirstName))
                {
                    ValidationFailureMessages.Add("first_name is a mandatory Field.");
                    validationFlag = false;
                }

                if (validationFlag && sqsMessageKey.FirstName.Length > 50)
                {
                    sqsMessageKey.FirstName = sqsMessageKey.FirstName.Substring(0, 50);
                }

                if (validationFlag && string.IsNullOrEmpty(sqsMessageKey.LastName))
                {
                    ValidationFailureMessages.Add("last_name is a mandatory Field.");
                    validationFlag = false;
                }

                if (validationFlag && sqsMessageKey.LastName.Length > 50)
                {
                    sqsMessageKey.LastName = sqsMessageKey.LastName.Substring(0, 50);
                }

                if (validationFlag && sqsMessageKey.Email.Length > 50)
                {
                    sqsMessageKey.Email = sqsMessageKey.Email.Substring(0, 50);
                }
                if (validationFlag && string.IsNullOrEmpty(sqsMessageKey.ExpiryDate))
                {
                    ValidationFailureMessages.Add("expiry_date is a mandatory Field.");
                    validationFlag = false;
                }
                if (validationFlag && string.IsNullOrEmpty(sqsMessageKey.AppStatus))
                {
                    ValidationFailureMessages.Add("app_status is a mandatory Field.");
                    validationFlag = false;
                }
                if (validationFlag && sqsMessageKey.AppStatus.Length > 20)
                {
                    ValidationFailureMessages.Add("app_status cannot have more than 20 characters.");
                    validationFlag = false;
                }
                if (validationFlag && string.IsNullOrEmpty(sqsMessageKey.Timedate))
                {
                    ValidationFailureMessages.Add("timedate is a mandatory Field");
                    validationFlag = false;
                }
                if (validationFlag && !DateTime.TryParse(sqsMessageKey.Timedate, out DateTime parseTimedate))
                {
                    ValidationFailureMessages.Add("timedate should be in a format which can be converted into DateTime.");
                    validationFlag = false;
                }
                if (validationFlag && string.IsNullOrEmpty(sqsMessageKey.EventType))
                {
                    ValidationFailureMessages.Add("event_type is a mandatory Field");
                    validationFlag = false;
                }
                if (validationFlag && !sqsMessageKey.EventType.Equals("New", StringComparison.OrdinalIgnoreCase) && !sqsMessageKey.EventType.Equals("Update", StringComparison.OrdinalIgnoreCase))
                {
                    ValidationFailureMessages.Add(@"event_type cannot have value other then 'New' or 'Update'.");
                    validationFlag = false;
                }
                if (validationFlag)
                {
                    if (!DateTime.TryParse(sqsMessageKey.ExpiryDate, out DateTime expiryDate))
                    {
                        ValidationFailureMessages.Add("expiry_date should be in a format which can be converted into smallDateTime.");
                        validationFlag = false;
                    }
                    else if (expiryDate < minSmallDateTime || expiryDate > maxSmallDateTime)
                    {
                        ValidationFailureMessages.Add("expiry_date should be between minSmallDateTime and maxSmallDateTime.");
                        validationFlag = false;
                    }
                }
                _logger.LogInformation("SQSMessages received from SQS queue validated successfully.");

            }
            catch (Exception validationException)
            {
                _logger.LogError(validationException, validationException.Message);
            }
            return ValidationFailureMessages;

        }


    }
}

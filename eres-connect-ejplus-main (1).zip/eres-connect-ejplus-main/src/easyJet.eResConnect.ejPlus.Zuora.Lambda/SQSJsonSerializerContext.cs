﻿using System.Text.Json.Serialization;
using Amazon.Lambda.SQSEvents;

namespace easyJet.eResConnect.ejPlus.Zuora.Lambda
{
    [JsonSerializable(typeof(SQSBatchResponse))]
    [JsonSerializable(typeof(SQSEvent))]
    public partial class SQSJsonSerializerContext : JsonSerializerContext
    {
    }
}

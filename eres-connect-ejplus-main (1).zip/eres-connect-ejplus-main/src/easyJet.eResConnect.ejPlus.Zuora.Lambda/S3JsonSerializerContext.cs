﻿using System.Text.Json.Serialization;
using Amazon.Lambda.S3Events;

namespace easyJet.eResConnect.ejPlus.Zuora.Lambda;

[JsonSerializable(typeof(S3Event))]
public partial class S3JsonSerializerContext : JsonSerializerContext
{
}